package Scannerexm;

import java.util.Scanner;

public class Scannerclass {
	public static void main(String[] args) {
		System.out.println("Enter your number");
		Scanner sc=new Scanner(System.in);
		
		 int i =sc.nextInt();
		 System.out.println(i);
		 
		 System.out.println("Enter your float value");
		float f=sc.nextFloat();
		 System.out.println(f);
		
		System.out.println("Enter your char value");
		char c=sc.next().charAt(0);
		 System.out.println(c);
	}

}
