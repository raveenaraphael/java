package prgPkg;

import java.util.Scanner;

public class classnew {

	public static void main(String[] args) {
		System.out.println("Enter three numbers");
		Scanner sc=new  Scanner (System.in);
			int x =sc.nextInt();
			System.out.println("X ="+x);
			int y=sc.nextInt();
			System.out.println("Y="+y);
			int z=sc.nextInt();
			System.out.println("Z="+z);
			if(x>y && x>z)
			{
				System.out.println("X is greater");
			}
			else if(y>x && y>z)
			{
				System.out.println("Y is greater");
				
			}
			else
			{
				System.out.println("Z is greater");
			}
	}
}
