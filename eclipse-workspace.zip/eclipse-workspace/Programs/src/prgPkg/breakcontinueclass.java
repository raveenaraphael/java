package prgPkg;

import java.util.Scanner;

public class breakcontinueclass {
    public static void main(String[] args) {
        System.out.println("Enter a number:");
        Scanner sc = new Scanner(System.in);
        int num = sc.nextInt();
        for(int i=0;i<=num;i++)
        {
        	if(i==4)
        	{
        		//break;
        		continue;
        	}
        	System.out.println(i);
        }

    }
}
