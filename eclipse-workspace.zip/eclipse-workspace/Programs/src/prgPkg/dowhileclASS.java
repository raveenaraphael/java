package prgPkg;

import java.util.Scanner;

public class dowhileclASS {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		  System.out.println("Enter the num");
   Scanner sc =new Scanner (System.in);
   int n =sc.nextInt();
   int i=1;
 
do
   {
	   System.out.println(i);
	   i++;
   }
while(i<=n);
	}

}
