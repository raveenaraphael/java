package prgPkg;

import java.util.Scanner;

public class multiplication {
	public static void main(String[] args) {
		System.out.println("Enter a num");
		Scanner sc = new Scanner(System.in);
		int a=sc.nextInt();
		int mul=0;
		for(int i=1;i<=10;i++)
		{
        	mul=	a*i;
        	System.out.println(a+"*"+i+"="+mul);
		}
		
	
}
}
