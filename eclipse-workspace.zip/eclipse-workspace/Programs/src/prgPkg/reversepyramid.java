package prgPkg;

import java.util.Scanner;

public class reversepyramid {


	    public static void main(String[] args) {
	        System.out.println("Enter the num");
	        Scanner sc = new Scanner(System.in);
	        int x = sc.nextInt();
	        int i,j;
		        for (i = x; i >= 0; i--) 
				{
				    for (j = x - i; j > 0; j--) 
					{
					
						 System.out.print("  ");	
					
				   }
				    for(j=0;j<=i;j++)
				    {
				    	System.out.print(" * ");	
				    }
				     System.out.println();	

	        }
	    }
	}
