package prgPkg;

import java.util.Scanner;

public class iflseclass {
public static void main(String[] args) {
	System.out.println("Enter two numbers");
Scanner sc=new  Scanner (System.in);
	int x =sc.nextInt();
	System.out.println("X ="+x);
	int y=sc.nextInt();
	System.out.println("Y="+y);
	if (x>y)
	{
		System.out.println("X is greater");
		
	}
	else
	{
	System.out.println("Y is greater");
	
	}

}
}