package prgPkg;

import java.util.Scanner;

public class dividespecificno {
	public static void main(String[] args) {
		System.out.println("Enter a number");
		Scanner sc=new  Scanner (System.in);
			int x =sc.nextInt();
			System.out.println("The number is ="+x);
	if(x % 2 == 0 && x % 5 == 0)
			{
				System.out.println("The number divided by both 2 and 5");
			}
	else if( x % 2 == 0)
			{
				System.out.println("The number is only divided by 2");
			}
	else if (x%5==0)
			{
				System.out.println("The number is only divided by 5");
			}
	else 
			{
				System.out.println("The number is not divisible by both 2 and 5");
			}
			
	}

}
