package prgPkg;

import java.util.Scanner;

public class Primclass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int flag=0;
		System.out.println("Enter a number");
		Scanner sc=new  Scanner (System.in);
			int x =sc.nextInt();

	if (x==0||x==1)
	{
		System.out.println("Number is not prime");
	}
	else
	{
	    	for(int i=2;i<=x/2;i++)
		   {
			if(x%i==0)
		     {
			flag=1;
			break;
	         }
	      }
	
     	if (flag==1) 
	    	System.out.println("num is  not prime");
	   else 
		System.out.println("num is prime");
	
	}

}
}
