package prgPkg;

import java.util.Scanner;

public class oddorevenclass {
	public static void main(String[] args) {
		System.out.println("Enter a number");
		Scanner sc=new  Scanner (System.in);
			int x =sc.nextInt();
			System.out.println("The number is ="+x);
			if(x % 2 == 0)
			{
				System.out.println("Number is even"+x);
			}
			else
			{
				System.out.println("Number is odd"+x);
			}
}
}