package prgPkg;

import java.util.Scanner;

public class prime {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		{
			System.out.println("Enter a number");
			Scanner sc=new  Scanner (System.in);
				int x =sc.nextInt();
				boolean prime=true;
				for(int i=2;i<x;i++)
				{
					if(x%i==0) {
						prime=false;
		          	break;
					}					
				}
		
				System.out.println(prime);
				if (prime=true) {
			
				}
			
		}
	}

}
