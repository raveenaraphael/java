package prgPkg;

import java.util.Scanner;

public class factorialclass {
	public static void main(String[] args) {
		  System.out.println("Enter the num");
		   Scanner sc =new Scanner (System.in);
		   int f=1;
		   int n =sc.nextInt();
		   for(int i=1;i<=n;i++)
		   {
			   f=f*i;
		   }
		   System.out.println("Factorial ="+f);
	}

}
