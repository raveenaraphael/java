package prgPkg;

import java.util.Scanner;

public class blooddonation {
public static void main(String[] args) {
	System.out.println("Enter the Age:-");
	Scanner sc = new Scanner (System.in);
	int age =sc.nextInt();
	System.out.println("Enter the Weight:-");
	int weight =sc.nextInt();
	if (age>18)
	{
		if(weight>50)
		{
			System.out.println("You can donate blood");
		}
		else
		{
			System.out.println("Under weight");
		}
	}
	else
	{
	System.out.println("You cannot donate blood ");
	}
}
}
