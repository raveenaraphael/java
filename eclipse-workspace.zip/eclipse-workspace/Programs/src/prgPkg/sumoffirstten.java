package prgPkg;

import java.util.Scanner;

public class sumoffirstten {
	public static void main(String[] args) {
		System.out.println("Enter a num");
		Scanner sc = new Scanner(System.in);
		int a=sc.nextInt();
		int sum=0;
		for(int i=1;i<=a;i++)
		{
			sum = sum+i;
		}
		System.out.println("Sum ="+sum);
		}

}
