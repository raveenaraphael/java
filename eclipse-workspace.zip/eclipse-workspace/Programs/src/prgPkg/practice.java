package prgPkg;

import java.util.Scanner;

public class practice {
public static void main(String[] args) {
	
    System.out.println("Enter a number:");
    Scanner sc = new Scanner(System.in);
    int num = sc.nextInt();
    int originalNum = num;
    int numDigits = 0,rem;

    // Counting the number of digits
  //  while (originalNum != 0) {
    	  
  //  originalNum /= 10;
// System.out.println(   originalNum);
  //    ++numDigits;
  //    System.out.println(   numDigits);
//    }

    
    
    while(originalNum!=0) {
    	
    
		 rem=originalNum%10;
	//	 System.out.println(   originalNum);
		 
		 originalNum=originalNum/10;
		 System.out.println(   originalNum);
    }
		 
    
}
}
