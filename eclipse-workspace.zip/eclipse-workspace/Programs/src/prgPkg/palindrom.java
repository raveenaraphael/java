package prgPkg;

import java.util.Scanner;

public class palindrom {
	public static void main(String[] args) {
		System.out.println("Enter the num");
		int rem=0,rev=0;
		Scanner sc =new Scanner (System.in);

		int x =sc.nextInt();
		int a=x;
	while(x!=0) {
		 rem=x%10;
		 rev=rev*10+rem;
		 x=x/10;
			
		}
//System.out.println("The reverse num is="+x);
 if (a==rev)
 {
	 System.out.println("The num is palindrom");
 }
 else
 {

	 System.out.println("The num is not palindrom");
}
}
}