package prgPkg;

import java.util.Scanner;

public class threenumclass {
	public static void main(String[] args) {
		System.out.println("Enter three numbers");
	Scanner sc=new  Scanner (System.in);
		int x =sc.nextInt();
		System.out.println("X ="+x);
		int y=sc.nextInt();
		System.out.println("Y="+y);
		int z=sc.nextInt();
		System.out.println("Z="+z);
	if (x>y) {
			if(x>z)
		   {
			System.out.println("X is greater");
	     	}
			else
			{
				System.out.println("Z is greater");
			}
	}
	else {
				if(y>z)
				{
					System.out.println("Y is Greater");
				}
				else
				{
					System.out.println("Z is greater");
				}
	}
	}
}
