package prgPkg;

import java.util.Scanner;

public class armstrong {
/*	public static void main(String[] args) {
		System.out.println("Enter a num");
		Scanner sc = new Scanner(System.in);
		int originalnum=sc.nextInt();
		int c= originalnum,rem=0,dig=0,arm=0;
		//find digits 
		
		while(originalnum>0)
		{
			dig++;
			originalnum=originalnum/10;
			
		}
		originalnum=c;
		//find Armstrong
		
		while(originalnum!=0) {
			 rem=originalnum%10;
			 originalnum=originalnum/10;
			 arm+=Math.pow(rem,dig);
			 
		}
		
		if (c==arm) {
			System.out.println("Armstrong");
		}
		else {
			System.out.println("Not Armtrong");
		}
		
	}*/

	    public static void main(String[] args) {
	        System.out.println("Enter a number:");
	        Scanner sc = new Scanner(System.in);
	        int num = sc.nextInt();
	        int originalNum = num;
	        int numDigits = 0;
	        int armstrong = 0;

	        // Counting the number of digits
	        while (originalNum != 0) {
	            originalNum /= 10;
	            ++numDigits;
	        }

	        originalNum = num;

	        // Calculating Armstrong number
	        while (originalNum != 0) {
	            int remainder = originalNum % 10;
	            armstrong += Math.pow(remainder, numDigits);
	            originalNum /= 10;
	        }

	        if (num == armstrong) {
	            System.out.println(num + " is an Armstrong number.");
	        } else {
	            System.out.println(num + " is not an Armstrong number.");
	        }
	    }
	}


