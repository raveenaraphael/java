package prgPkg;

import java.util.Scanner;

public class prgclass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
   System.out.println("Enter two numbers to swap");
   Scanner sc=new Scanner (System.in);
   int a= sc.nextInt();
   int b = sc.nextInt();
   System.out.println("Before swap a ="+a);
   System.out.println("Before sawp b="+b);
   
   a=a+b;
   b=a-b;
   a=a-b;
   
   System.out.println("After swap a="+a);
   System.out.println("After swap b="+b);
   
		   
   
	}

}
