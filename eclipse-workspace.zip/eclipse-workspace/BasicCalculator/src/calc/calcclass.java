package calc;
import java.util.Scanner;
public class calcclass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
         System.out.println("Enter the Two Numbers");
         Scanner sc=new Scanner(System.in);
         int a= sc.nextInt();
         int b= sc.nextInt();
         System.out.println("Num1 ="+a);
         System.out.println("Num2 = "+b);
	}

}
