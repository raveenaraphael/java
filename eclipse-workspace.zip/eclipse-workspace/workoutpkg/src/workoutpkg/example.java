package workoutpkg;

public class example {

	public static void main(String []args) {
		// TODO Auto-generated method stub
		int a=124;
		float b=22.44f;
		double c=544447545654.5454554d;
		boolean f=true;
		char v='d';
		System.out.println("int ="+a+ "  " +"float =" +b + "  " +"double =" +c + "  " +"boolean =" +f+ "  " +"char ="  +v);
		
	}

}
