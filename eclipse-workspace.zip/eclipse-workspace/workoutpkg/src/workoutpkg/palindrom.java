package workoutpkg;

import java.util.Scanner;

public class palindrom {
	public static void main(String[] args) {
		String x = new String();
		String r = "";
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the String");
		x = sc.nextLine();
		System.out.println("The string is:-" + x);
		for (int v = x.length() - 1; v >= 0; v--) {
			r = r + x.charAt(v);
		}
		if (x.equals(r)) {
			System.out.println("palindrom");
		} else {

			System.out.println("Not palindrom");
		}
	}

}
