package workoutpkg;

public class helloprg {
	public static void main(String[] args) {
		System.out.println("HEllO WORLD");
		
	}

}
