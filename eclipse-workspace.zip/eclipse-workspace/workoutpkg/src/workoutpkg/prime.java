package workoutpkg;

import java.util.Scanner;

public class prime {
	public static void main(String[] args) {
		System.out.println("Enter a num");
		Scanner sc = new Scanner(System.in);
		int x = sc.nextInt();
		int flag = 0;
		for (int i = 2; i >= x; i++) {
			if (x != 0 && x != 1) {
				flag = 1;
				break;
			}
		}

		if (flag == 0)
			System.out.println(" not Prime");
		else
			System.out.println("Prime");
	}
}
