package Polymorphism;

public class constuctoroverloding {

	String name;
	int age;

	public constuctoroverloding() {
		System.out.println("Hello");
	}

	public constuctoroverloding(int age) {
		this.age = age;
		System.out.println(this.age);
	}

	public constuctoroverloding(String name) {
		this.name = name;
		System.out.println(this.name);
	}

	public constuctoroverloding(int age, String name) {
		this.age = age;
		this.name = name;
		System.out.println(this.age);
		System.out.println(this.name);

	}

	public static void main(String[] args) {

		constuctoroverloding emp = new constuctoroverloding();
		constuctoroverloding emp1 = new constuctoroverloding(25);
		constuctoroverloding emp2 = new constuctoroverloding("Raveena");
		constuctoroverloding emp3 = new constuctoroverloding(65, "sMathew");

	}
}