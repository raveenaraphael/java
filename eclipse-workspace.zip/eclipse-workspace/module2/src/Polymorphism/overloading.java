package Polymorphism;

public class overloading {

	void sum(int a, int b) {
		int sum = a + b;
		System.out.println(sum);
	}

	void sum(int x) {
		int sum = x + x;
		System.out.println(sum);
	}

	void sum(int x, double y) {
		double sum = x + y;
		System.out.println(sum);
	}

}
