package Polymorphism;

class A {
	void sum(int i, int x) {
		int sum = i + x;
		System.out.println(sum);
	}
}

class B extends A {
	void sum(int i, int x) {
		int sum = i + x;
		System.out.println("child  = " + sum);
	}

}

public class overriding {
	public static void main(String[] args) {

		B obj1 = new B();
		obj1.sum(40, 45);

	}
}
//first execute the object created class