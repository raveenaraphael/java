package Polymorphism;

public class Overloadingmain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		overloading obj = new overloading();
		obj.sum(20, 20);
		obj.sum(40);
		obj.sum(30, 50.5);
	}

}
