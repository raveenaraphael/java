package module2;

public class student {
	int id, age;
	String name;

	public void display() {
		System.out.println("welcome");
	}

//	public void sum(int a, int b) {
//		int sum= a+b;
//		System.out.println(sum);
//	}

}
