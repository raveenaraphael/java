package module2;

public class stringmethods {
public static void main(String[] args) {
	String s1="Raveena";
	System.out.println(s1.toUpperCase());
	System.out.println(s1.toLowerCase());
	String s2="            Raveena";
	System.out.println(s2.trim());
	System.out.println(s1.charAt(5));
	System.out.println(s1.length());
	
	System.out.println(s1.replace("Ra","kk"));
	
	String s3="Raphael";
	System.out.println(s1+s3);
	
	
	s1.concat(s3);
	System.out.println(s1);
	
	
	String s4=s1.concat(s2);
	System.out.println(s4);
	
	
	String s5="sachin how are you";
	System.out.println(s5.contains("are"));
	
	System.out.println(s5.substring(1,4));
	
	String joinString1=String.join("-","welcome","to","javatpoint");  
	System.out.println(joinString1);
}
}
 