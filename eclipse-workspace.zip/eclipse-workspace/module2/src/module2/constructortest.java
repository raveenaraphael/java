package module2;

public class constructortest {
	public static void main(String[] args) {
		constructor cons = new constructor(111, "Kiran", 29);
		cons.display();
	}

}
