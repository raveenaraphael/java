package module2;

import java.util.Scanner;

public class stringreading {
	public static void main(String[] args) {
	
			Scanner sc =new Scanner (System.in);
			   System.out.println("Enter the string ");
			  // String str=sc.next();
			   
			   String str=sc.nextLine();
			   
			   System.out.println(str);
	}

}
