package module2;

import java.util.Scanner;

public class complines {

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the string 1 ");
		String str = sc.nextLine();
		System.out.println(str);

		System.out.println("Enter the string 2 ");
		String str1 = sc.nextLine();
		System.out.println(str1);

		if (str.equals(str1)) {
			System.out.println("same string =" + str + str1);
		} else {
			System.out.println("not same string=" + str + str1);
		}

	}

}
