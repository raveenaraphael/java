package module2;

public class Employee {
	int id, salary;
	String name;

	public void display() {
		System.out.println(id + " " + name + " " + salary);
	}

}
