package module2;

import java.util.Scanner;

public class finddiffchar {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the string ");
		String str = sc.nextLine();
		System.out.println(str);

		int i, up = 0, low = 0, num = 0, spl = 0;

		for (i = 0; i < str.length(); i++) {
			System.out.println(str.charAt(i));
			if (str.charAt(i) >= 'a' && str.charAt(i) <= 'z') {
				low = low + 1;
			} else if (str.charAt(i) >= 'A' && str.charAt(i) <= 'Z') {
				up = up + 1;
			} else if (str.charAt(i) >= '0' && str.charAt(i) <= '9') {
				num = num + 1;
			} else {
				spl = spl + 1;
			}
		}

		System.out.println("Upper:-" + up);
		System.out.println("lower:-" + low);
		System.out.println("special:-" + spl);
		System.out.println("number:-" + num);

	}
}
