package module2;

public class studenttest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
student std=new student();
std.id=1;
std.name="Raveena";
std.age=25;
std.display() ;
System.out.println(std.id+" "+std.name+" "+std.age);
std.sum(100, 200);
	}

}
