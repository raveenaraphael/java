package module2;

import java.util.Scanner;
public class stringPalindrom {
	
	public static void main(String[] args) {	
		
	  String org=new String();
	   String rev="";
	   Scanner sc =new Scanner (System.in);
	   System.out.println("Enter the string ");
        org=sc.nextLine();
	   System.out.println("The string is="+org);
	 
	   for (int i=org.length()-1;i>=0;i--)
	   {
		   rev=rev+org.charAt(i);
	   }

	
	// if(org==rev)
	   if(org.equals(rev))
	 {
		System.out.print("The string is palindrom");
	  }
	 else
	 {
		 System.out.print("The string is not palindrom");
    	}

}
}