package module2;

public class cartest {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
car st=new car();
st.id=1001;
st.series=7;
st.name="BMW";
st.color="violet";
System.out.println(st.id+"  "+st.name+"  "+st.series+"  "+st.color);
}
}