package module2;

public class buffersrting {
public static void main(String[] args) {
	StringBuffer s=new StringBuffer("Hello");
	
	StringBuilder str1=new StringBuilder("Welcome to java");
	
	
	//StringBuffer
	System.out.println(" StringBuffer ");
	System.out.println("------------------");

	
	System.out.println(s);
	System.out.println("  ");
	
    s.append("java");
	System.out.println(s);
	System.out.println("  ");
	
	   s.insert(2,"jaava");
	System.out.println(s);
	System.out.println("  ");
	
	   s.replace(2, 6, "jaava");
	System.out.println(s);
	
	System.out.println("  ");

	   s.delete(1, 6);
	System.out.println(s);
	System.out.println("  ");
	
	   s.reverse();
	System.out.println(s);
	System.out.println("  ");
	System.out.println("  ");
	
	
	
	
	//StringBuilder
	System.out.println(" StringBuilder ");
	System.out.println("------------------");
	System.out.println("  ");
	
	

	System.out.println(str1);
	System.out.println("  ");
	
	str1.append("java");
	System.out.println(str1);
	System.out.println("  ");
	
	str1.insert(2,"jaava");
	System.out.println(str1);
	System.out.println("  ");
	
	str1.replace(2, 6, "jaava");
	System.out.println(str1);
	
	System.out.println("  ");

	str1.delete(1, 6);
	System.out.println(str1);
	System.out.println("  ");
	
	str1.reverse();
	System.out.println(str1);
	System.out.println("  ");
	
	

}
}
