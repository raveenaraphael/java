package module2;

public class Employeetest {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Employee emp = new Employee();
		emp.id = 101;
		emp.name = "Raveena";
		emp.salary = 250000;
		emp.display();
	}
}