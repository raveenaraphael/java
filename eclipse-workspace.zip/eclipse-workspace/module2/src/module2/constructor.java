package module2;

public class constructor {
	int id, salary;
	String name;

	public constructor(int id, String name, int salary) {

		this.id = id;
		this.name = name;
		this.salary = salary;
	}

	public void display() {
		System.out.println(id + " " + name + " " + salary);
	}

}
