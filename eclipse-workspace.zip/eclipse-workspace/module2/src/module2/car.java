package module2;

public class car {
	int id,series;
	String name,color;
}
