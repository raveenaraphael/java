package module2;

public class thisStudent {

	int id, age;
	String name;

	public void insert(int id, String name, int age) {

		this.id = id;
		this.name = name;
		this.age = age;
	}

	public void display() {
		System.out.println(id + " " + name + " " + age);
	}
}
