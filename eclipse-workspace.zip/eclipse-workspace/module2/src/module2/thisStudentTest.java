package module2;

public class thisStudentTest {
	public static void main(String[] args) {
		thisStudent std = new thisStudent();
		std.insert(1, "Raveena", 25);
		std.display();
	}

}
