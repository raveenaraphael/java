package module2;

import javax.jws.soap.SOAPBinding;

public class string {
	public static void main(String[] args) {
		
		String s1="hello";
		String s2="hello";
		String s3="helloworld";
		String s4="helloworld";
		
		System.out.println(s1==s2);
		System.out.println(s1==s3);
		System.out.println(s4==s3);
		
		
		System.out.println(s1.equals(s2));
		System.out.println(s1.equals(s3));
		System.out.println(s3.equals(s4));
		

		System.out.println(s1.compareTo(s2));
		System.out.println(s1.compareTo(s3));
		System.out.println(s3.compareTo(s4));
		
	}

}
