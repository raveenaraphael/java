package module2;

import java.util.Scanner;

public class stringreverse {
	public static void main(String[] args) {		
			
		   String org=new String();
		   String rev=" ";
		   Scanner sc =new Scanner (System.in);
		   System.out.println("Enter the string ");
           org=sc.nextLine();
		   System.out.println("The string is="+org);
		 
		   for (int i=org.length()-1;i>=0;i--)
		   {
			   rev=rev+org.charAt(i);
		   }
		  
           System.out.println("The reversed string is="+rev);
}

}



