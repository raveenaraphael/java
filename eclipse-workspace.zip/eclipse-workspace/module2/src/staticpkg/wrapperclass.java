package staticpkg;

public class wrapperclass {
	public static void main(String[] args) {
		String s = "1000";
		int x = Integer.parseInt(s);
		System.out.println("String=" + x + 100);

		int i = 10;
		String s1 = Integer.toString(i);
		System.out.println("Intger=" + s1 + 100);

	}

}
