package staticpkg;

public class enumclass {
	enum dir {
		north, south, east, west
	};

	public static void main(String[] args) {
		System.out.println(dir.east);

		for (dir d : dir.values()) {
			System.out.println(d);
		}
	}

}
