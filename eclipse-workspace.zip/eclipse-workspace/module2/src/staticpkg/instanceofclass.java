package staticpkg;

class ani {
}

class child extends ani {

}

public class instanceofclass {
	public static void main(String[] args) {
		child c = new child();
		System.out.println(c instanceof ani);
	}
}
