package staticpkg;

public class staticmethod {
	static void sum(int a, int b) {
		int sum = a + b;
		System.out.println(sum);
	}

	void sum1(int a, int b) {
		int sum1 = a + b;
		System.out.println(sum1);
	}
}
