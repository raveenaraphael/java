package staticpkg;

class parent {
	String clr = "violet";
}

class child1 extends parent {
	String clr = "red";

	void display() {
		System.out.println(super.clr);
	}
}

public class superkeyclass {
	public static void main(String[] args) {
		child1 c1 = new child1();
		c1.display();

	}

}
