package staticpkg;

public class staticblock {
	static {
		System.out.println("hello");
	}

	public static void main(String[] args) {
		System.out.println("HAI");
	}
}
