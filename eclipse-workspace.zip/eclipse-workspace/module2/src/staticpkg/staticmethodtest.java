package staticpkg;

public class staticmethodtest {
	public static void main(String[] args) {
		staticmethod.sum(10, 40);
		staticmethod st = new staticmethod();
		st.sum1(20, 20);
	}
}
