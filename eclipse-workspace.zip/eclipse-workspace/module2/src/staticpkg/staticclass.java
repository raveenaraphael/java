package staticpkg;

public class staticclass {
	int id;
	String name;
	static String college = "eeregcx";

	public staticclass(int id, String name) {
		this.id = id;
		this.name = name;

	}

	public String toString() {
		return id + " " + name + " " + college;
	}

}
