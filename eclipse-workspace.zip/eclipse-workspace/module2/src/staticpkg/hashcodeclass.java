package staticpkg;

import abstractclass.test;

public class hashcodeclass {
	public static void main(String[] args) {
		test obj1 = new test();
		test obj2 = new test();
		System.out.println(obj1.equals(obj2));
		System.out.println(obj1.hashCode());
		System.out.println(obj2.hashCode());
	}
}
