package staticpkg;

public class finalvariableclasss {
	final int speed = 90;

//final variable cannot change
	void run() {
		speed = 300;
	}

	public static void main(String[] args) {
		finalvariableclasss obj = new finalvariableclasss();
		obj.run();
	}
}