package staticpkg;

public class staticclasstest {

	public static void main(String[] args) {
		staticclass st = new staticclass(1, "raveena");
		System.out.println(st);

		staticclass st1 = new staticclass(2, "raphael");
		System.out.println(st1);

		staticclass st2 = new staticclass(3, "neethu");
		st2.college = "adsagfshh";
		System.out.println(st2);

		staticclass st3 = new staticclass(4, "Kiran");
		System.out.println(st3);

		staticclass st4 = new staticclass(5, "mathew");
		System.out.println(st4);

	}

}
