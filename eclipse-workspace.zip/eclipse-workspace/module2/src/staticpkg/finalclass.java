package staticpkg;

final class A {
	void sum(int i, int x) {
		int sum = i + x;
		System.out.println(sum);
	}
}

class B1 extends A {
	void sum(int i, int x) {
		int sum = i + x;
		System.out.println("child  = " + sum);
	}

}

public class finalclass {
	public static void main(String[] args) {

		B1 obj1 = new B1();
		obj1.sum(40, 45);

	}
}
