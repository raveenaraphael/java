package abstractclass;

public class classabstracttest {
	public static void main(String[] args) {
		classabstact c1 = new ford();
		System.out.println(c1.display(45));
		c1.display();
		c1.show();

		ford f = new ford();
		f.display();
		System.out.println(f.display(80));
		f.show();

	}
}
