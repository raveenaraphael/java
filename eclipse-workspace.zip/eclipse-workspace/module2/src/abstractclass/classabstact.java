package abstractclass;

public abstract class classabstact {

	public abstract void display();

	public abstract int display(int a);

	void show() {
		System.out.println("hai");
	}
}

class ford extends classabstact {
	public void display() {
		System.out.println("ford");
	}

	public int display(int a) {
		return a;
	}

}
