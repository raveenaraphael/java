package abstractclass;

public class test {
	public static void main(String[] args) {
		abstractionwithoutchild c1 = new abstractionwithoutchild() {
			public int regno(int a) {
				return a;

			}

			public void display() {
				System.out.println("hello");
			}

		};
		c1.display();
		System.out.println(c1.regno(12457));
	}
}
