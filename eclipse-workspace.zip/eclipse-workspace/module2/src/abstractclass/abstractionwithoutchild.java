package abstractclass;

public abstract class abstractionwithoutchild {

	public abstract void display();

	public abstract int regno(int a);
}
