package inheritance;

public interface sampletest {
	public static void main(String[] args) {
		sample sc = new sample() {

			@Override
			public int regno(int a) {
				// TODO Auto-generated method stub
				return a;
			}

			@Override
			public void display() {
				// TODO Auto-generated method stub
				System.out.println("hello");
			}
		};
		sc.display();
		System.out.println(sc.regno(5678));
	}
}
