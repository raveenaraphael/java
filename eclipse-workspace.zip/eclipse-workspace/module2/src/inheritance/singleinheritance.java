package inheritance;

class Animal {
	void eat() {
		System.out.println("Eating");
	}

	void walk() {
		System.out.println("Walking");
	}
}

class dog extends Animal {
	void bark() {
		System.out.println("Barking");
	}
}

public class singleinheritance {

	public static void main(String[] args) {
		dog d = new dog();
		d.bark();
		d.eat();
		d.walk();
	}

}
