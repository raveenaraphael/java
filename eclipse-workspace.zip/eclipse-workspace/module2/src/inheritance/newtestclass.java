package inheritance;
import paksample.newpkg;
public class newtestclass {
	public static void main(String[] args) {
		newclss std1 = new newclss();
		std1.setId(1001);
		std1.setMark(200);
		std1.setName("Kiran");

		
System.out.println(std1);
//		System.out.println(std1.getid());
//		System.out.println(std1.getmark());
//		System.out.println(std1.getname());
	}
}
