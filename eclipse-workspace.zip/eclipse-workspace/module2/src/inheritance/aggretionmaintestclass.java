package inheritance;

public class aggretionmaintestclass {
	public static void main(String[] args) {
		addressclassaggration ad = new addressclassaggration("qwert", "kochi", "Kerala");
		employeeaddresagration emp = new employeeaddresagration(1, "raveena", 23000, ad);
		emp.display();
	}
}
