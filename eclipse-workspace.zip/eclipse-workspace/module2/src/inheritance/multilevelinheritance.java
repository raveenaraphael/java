package inheritance;

class Animal3 {
	void eat() {
		System.out.println("Eating");
	}

	void walk() {
		System.out.println("Walking");
	}
}

class dog1 extends Animal3 {
	void bark() {
		System.out.println("Barking");
	}
}

class babydog extends dog1 {
	void play() {
		System.out.println("playing");
	}
}

public class multilevelinheritance {
	public static void main(String[] args) {
		babydog d = new babydog();
		d.bark();
		d.eat();
		d.walk();
		d.play();
	}
}
