package inheritance;

public interface sample {

	void display();

	int regno(int a);

}
