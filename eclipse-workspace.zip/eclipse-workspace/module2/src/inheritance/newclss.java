package inheritance;

public class newclss {
	private int id;
	private int mark;
	private String name;

	public void setId(int id) {
		this.id = id;

	}

	public int getid() {
		return this.id;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getname() {
		return this.name;
	}

	public void setMark(int mark) {
		this.mark = mark;
	}

	public int getmark() {
		return this.mark;
	}

	public String toString()

	{
		return id + " " + name + " " + mark;
	}

}
