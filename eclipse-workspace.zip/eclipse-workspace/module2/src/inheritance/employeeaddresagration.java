package inheritance;

public class employeeaddresagration {
	int id, salary;
	String name;
	addressclassaggration add;

	public employeeaddresagration(int id, String name, int salary, addressclassaggration add) {
		// TODO Auto-generated constructor stub

		this.id = id;
		this.name = name;
		this.add = add;

	}

	public void display() {
		System.out.println(id + " " + name + " " + salary);
		System.out.println(add.city);
		System.out.println(add.housename);
		System.out.println(add.state);
	}

}
