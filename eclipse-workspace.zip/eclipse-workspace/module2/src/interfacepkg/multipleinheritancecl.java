package interfacepkg;

interface animal {// parent 1
	void display();

}

interface Fish {// parent 2
	void display();

}

class dog1 implements animal, Fish { // implements used for extends

	@Override
	public void display() {
		System.out.println("hello");
	}
}

public interface multipleinheritancecl {

	public static void main(String[] args) {
		dog1 d = new dog1();
		d.display();

	}

}
