package interfacepkg;

class Animal3 {
	void eat() {
		System.out.println("Eating");
	}
}

class Fish {
	void swim() {
		System.out.println("Swimming");
	}
}

class dog1 implements Animal3, Fish {
	void bark() {
		System.out.println("Barking");
	}
}

public class multipleinheritanceclass {

	public static void main(String[] args) {
		dog1 d new=  dog1();
	d.bark();
	d.eat();
	
		}

}
