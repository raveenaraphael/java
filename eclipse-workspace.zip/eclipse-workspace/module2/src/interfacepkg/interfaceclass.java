package interfacepkg;

public interface interfaceclass {
	void display();

	int sum(int a, int b);

}

class ford implements interfaceclass {
	public void display() {
		System.out.println("ford");
	}

	public int sum(int a, int b) {
		return a + b;
	}

}
