package interfacepkg;

public interface interfacetestclass {
	public static void main(String[] args) {

		interfaceclass s1 = new ford();

		s1.display();
		System.out.println(s1.sum(12, 12));

	}
}
