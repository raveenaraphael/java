package test;

import java.util.Scanner;

public class Rectangle {

	public static void main(String[] args) {
		int width = 0, hight = 0, area = 0, perimeter = 0;
		System.out.println("Enter the width and height ");
		Scanner sc = new Scanner(System.in);
		width = sc.nextInt();
		hight = sc.nextInt();
		System.out.println("width =" + width);
		System.out.println("hight = " + hight);

		area = width * hight;
		System.out.println("area = " + area);
		perimeter = 2 * (width + hight);
		System.out.println("perimeter = " + perimeter);
	}
}
