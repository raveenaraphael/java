package test;

public class rectangleclass {

	public int area(int w, int h) {
		int x = w * h;
		return x;

	}

	public int perimeter(int w, int h) {
		int p = 2 * (w + h);
		return p;

	}

	public static void main(String[] args) {
		rectangleclass rc = new rectangleclass();

		System.out.println("Area=" + rc.area(2, 2));
		System.out.println("Perimeter=" + rc.perimeter(4, 4));
	}
}