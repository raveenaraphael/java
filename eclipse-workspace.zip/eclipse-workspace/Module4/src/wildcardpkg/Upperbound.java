package wildcardpkg;

import java.util.ArrayList;

public class Upperbound {

	public static void display(ArrayList<? extends Number> list) {
		System.out.println(list);
	}

	public static void main(String[] args) {
		ArrayList<Integer> list = new ArrayList<>();
		list.add(123);
		list.add(222);
		list.add(245);

		ArrayList<Float> list1 = new ArrayList<>();
		list1.add(123.23f);
		list1.add(222.22f);
		list1.add(245.77f);

		display(list1);
		display(list);

	}

}
