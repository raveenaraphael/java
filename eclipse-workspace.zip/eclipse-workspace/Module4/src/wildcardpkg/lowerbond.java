package wildcardpkg;

import java.util.ArrayList;

public class lowerbond {

	public static void display(ArrayList<? super Integer> list) {
		System.out.println(list);
	}

	public static void main(String[] args) {
		ArrayList<Integer> list = new ArrayList<>();
		list.add(123);
		list.add(222);
		list.add(245);

		ArrayList<Number> list1 = new ArrayList<>();
		list1.add(123);
		list1.add(222);
		list1.add(245);

		display(list);
		display(list1);
	}

}
