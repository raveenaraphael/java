package wildcardpkg;

import java.util.ArrayList;

public class unbound {
	public static void display(ArrayList<?> list) {
		System.out.println(list);
	}

	public static void main(String[] args) {
		ArrayList<Integer> list = new ArrayList<>();
		list.add(123);
		list.add(222);
		list.add(245);

		ArrayList<String> list1 = new ArrayList<>();
		list1.add("raveena");
		list1.add("raphael");
		list1.add("kiran");

		display(list);
		display(list1);
	}

}
