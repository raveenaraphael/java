package list;

import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.Scanner;

public class linkedhashset {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		LinkedHashSet<Integer> list = new LinkedHashSet<>();

		list.add(123);
		list.add(444);
		list.add(773);

		Iterator<Integer> itr = list.iterator();

		while (itr.hasNext()) {
			System.out.println(itr.next());
		}

	}

}
