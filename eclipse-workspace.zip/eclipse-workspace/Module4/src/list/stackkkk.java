package list;

import java.util.Iterator;
import java.util.Scanner;
import java.util.Stack;

public class stackkkk {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		Stack<Integer> list = new Stack<>();

		list.push(123);
		list.push(123);
		list.push(123);

		Iterator<Integer> itr = list.iterator();

		while (itr.hasNext()) {
			System.out.println(itr.next());
		}
		System.out.println(list.contains(123));
	}

}
