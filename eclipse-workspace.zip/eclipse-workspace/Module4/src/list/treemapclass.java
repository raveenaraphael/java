package list;

import java.util.Map;
import java.util.TreeMap;

public class treemapclass {

	public static void main(String[] args) {

		TreeMap<Integer, String> tree = new TreeMap<>();
		tree.put(1, "Raveena");
		tree.put(2, "Raphael");

		for (Map.Entry<Integer, String> m : tree.entrySet()) {
			System.out.println(m.getKey() + " " + m.getValue());
		}
	}

}
