package list;

import java.util.ArrayList;
import java.util.Scanner;

public class studentMain {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		ArrayList<student> list = new ArrayList<student>();

		student s1 = new student(1, "raveena", 25);
		student s2 = new student(2, "Kiran", 28);
		list.add(s1);
		list.add(s2);

		list.add(new student(3, "sdhdviuosdvh", 20));
//		
//		
//	iterator<Integer> itr=list.iterator();
//		whi

		for (student std : list) {
			System.out.println(std);

		}
	}

}
