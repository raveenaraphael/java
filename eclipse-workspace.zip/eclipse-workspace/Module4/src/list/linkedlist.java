package list;

import java.util.Iterator;
import java.util.LinkedList;
import java.util.Scanner;

public class linkedlist {

	// String

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		LinkedList<String> list = new LinkedList<String>();

		list.add("rtyu");

		list.add("dfhj");

		list.add("iom");

		LinkedList<String> list2 = new LinkedList<String>();

		list2.add("vvv");

		list2.add("mmm");

		list2.add("qqq");

		// list.removeFirst();

		// list.removeLast();

		// list.clear();
		list.addAll(list2);
		list2.add(2, "rrr");

		// Iterator<String> itr = list.iterator();
		Iterator<String> itr = list.descendingIterator();

		while (itr.hasNext()) {
			System.out.println(itr.next());
		}

	}
}
