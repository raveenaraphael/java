package list;

import java.util.Scanner;
import java.util.TreeSet;

public class TREESET {

	// INTEGER

//	public static void main(String[] args) {
//		Scanner sc = new Scanner(System.in);
//		TreeSet<Integer> list = new TreeSet<>();
//
//		list.add(4);
//		list.add(0);
//		list.add(6);
//		// Iterator<Integer> itr = list.iterator();
//		Iterator<Integer> itr = list.descendingIterator();
//
//		while (itr.hasNext()) {
//			System.out.println(itr.next());
//
//		}
////		System.out.println(list.pollFirst());
////		System.out.println(list.pollLast());
//
//	}
//}

	// STRING

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		TreeSet<String> list = new TreeSet<>();

		list.add("A");
		list.add("B");
		list.add("C");
		list.add("D");
		list.add("E");

		System.out.println(list);
		System.out.println("reverse" + list.descendingSet());
		System.out.println("headset" + list.headSet("C", true));
		System.out.println("subset" + list.subSet("A", false, "C", true));
		System.out.println("tailset" + list.tailSet("C", false));
		System.out.println("subset" + list.subSet("A", "C"));
		System.out.println("tailset" + list.tailSet("C"));
		System.out.println("headset" + list.headSet("C"));
	}
}
