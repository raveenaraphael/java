package list;

import java.util.LinkedList;
import java.util.Scanner;

public class BookMain {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		LinkedList<Book> bk = new LinkedList<Book>();

		bk.add(new Book(12, 45, "gyu", " hhh", "ghjj"));
		bk.add(new Book(2, 45, "gyu", " hhh", "ghjj"));
		bk.add(new Book(18, 45, "rrr", " hhh", "ghjj"));
		bk.add(new Book(62, 45, "gyu", " hhh", "ghjj"));
		bk.add(new Book(16, 45, "gyu", " hhh", "ghjj"));
		bk.add(new Book(18, 45, "gyu", " hhh", "ghjj"));

		for (Book std : bk) {
			System.out.println(std);

		}
	}

}
