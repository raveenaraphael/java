package list;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.Scanner;

public class testduplicationremove {
	public static void main(String[] args) {
//		Scanner sc = new Scanner(System.in);
//		Set<String> dup1 = new HashSet<>();
//
//		dup1.add("apple");
//		dup1.add("orange");
//		dup1.add("mango");
//		dup1.add("orange");
//		dup1.add("banana");
//
//		for (String d : dup1) {
//
//			System.out.println(d);
//		}
//
//	}
//
//}
		Scanner sc = new Scanner(System.in);
		ArrayList<String> list = new ArrayList<String>();

		list.add("apple");
		list.add("orange");
		list.add("mango");
		list.add("orange");
		list.add("banana");

		Iterator<String> itr = list.iterator();
		System.out.println("Iterator Elements");
		while (itr.hasNext()) {
			System.out.println(itr.next());

		}

		int s = list.size() - 1;
		list.remove(s);
		for (String d : list) {

			System.out.println("Last Removed Element=" + d);
		}
	}
}