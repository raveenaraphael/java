package list;

public class Book {

	int id, quantity;
	String name, author, publisher;

	public Book(int id, int quantity, String name, String author, String publisher) {
		this.id = id;
		this.quantity = quantity;
		this.name = name;
		this.author = author;
		this.publisher = publisher;

	}

	public String toString() {
		return id + " " + quantity + " " + name + " " + author + " " + publisher;

	}
}
