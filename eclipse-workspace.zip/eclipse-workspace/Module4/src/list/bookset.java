package list;

public class bookset {

	int id;
	String name;

	public bookset(int id, String name) {
		this.id = id;
		this.name = name;

	}

	public String toString() {
		return id + " " + name;

	}
}
