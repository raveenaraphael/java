package list;

import java.util.ArrayList;

public class reducetest {
	public static void main(String[] args) {
		ArrayList<>
	}

}
