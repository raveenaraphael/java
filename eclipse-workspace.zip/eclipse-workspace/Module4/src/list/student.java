package list;

public class student {

	int id, age;
	String name;

	public student(int id, String name, int age) {
		this.id = id;
		this.name = name;
		this.age = age;
	}

	public String toString() {
		return id + " " + name + " " + age;

	}
}
