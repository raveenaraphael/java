package list;

public class booklinkedhashset {

	int id;
	String name;

	public booklinkedhashset(int id, String name) {
		this.id = id;
		this.name = name;

	}

	public String toString() {
		return id + " " + name;

	}
}
