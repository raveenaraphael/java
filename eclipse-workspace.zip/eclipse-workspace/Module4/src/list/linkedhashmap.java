package list;

import java.util.LinkedHashMap;
import java.util.Map;

public class linkedhashmap {
	public static void main(String[] args) {

		LinkedHashMap<Integer, String> hMap = new LinkedHashMap<>();
		hMap.put(1, "Raveena");
		hMap.put(2, "Raphael");
		hMap.put(3, "Kiran");
		hMap.put(4, "Vincy");

		for (Map.Entry<Integer, String> m : hMap.entrySet()) {
			System.out.println(m.getKey() + " " + m.getValue());
		}
	}

}
