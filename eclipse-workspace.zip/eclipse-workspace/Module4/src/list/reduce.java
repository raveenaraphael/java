package list;

public class reduce {

}
