package list;

import java.util.HashSet;
import java.util.Scanner;

public class booklinkedhashsetmain {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		HashSet<booklinkedhashset> bk = new HashSet<booklinkedhashset>();

		bk.add(new booklinkedhashset(1, "raveena"));
		bk.add(new booklinkedhashset(2, "kiran"));
		bk.add(new booklinkedhashset(2, "kiran"));
		bk.add(new booklinkedhashset(1, "raveena"));

		for (booklinkedhashset std : bk) {
			System.out.println(std);

		}
	}

}
