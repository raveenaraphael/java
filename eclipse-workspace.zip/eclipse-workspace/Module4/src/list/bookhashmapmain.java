package list;

import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class bookhashmapmain {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		HashMap<Integer, String> bk = new HashMap<Integer, String>();

		bk.put(11, "ryuu");
		bk.put(12, "gfdh");

		for (Map.Entry<Integer, String> m : bk.entrySet()) {
			System.out.println(m.getKey() + " " + m.getValue());
		}

	}
}
