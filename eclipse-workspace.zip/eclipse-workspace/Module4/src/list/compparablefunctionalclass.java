package list;

import java.util.ArrayList;
import java.util.Collections;

public class compparablefunctionalclass {
	public static void main(String[] args) {
		ArrayList<compparablefunctional> aL = new ArrayList<compparablefunctional>();

		aL.add(new compparablefunctional(1, "ttt", 22));
		aL.add(new compparablefunctional(2, "rrr", 24));
		aL.add(new compparablefunctional(3, "uuuu", 25));
		Collections.sort(aL);
		for (compparablefunctional st : aL) {
			System.out.println(st.rollno + " " + st.name + " " + st.age);
		}
	}
}