package list;

import java.util.stream.Stream;

public class foreach {

	public static void main(String[] args) {

		System.out.println("foreach");
		Stream.iterate(1, ele -> ele + 1).filter(ele -> ele % 5 == 0).limit(5).forEach(System.out::println);

	}
}
