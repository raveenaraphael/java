package list;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class studentstreammain {
	public static void main(String[] args) {
		List<studentstream> list = new ArrayList<studentstream>();

		list.add(new studentstream(1, "hp", 25000));
		list.add(new studentstream(1, "hp", 95000));
		list.add(new studentstream(1, "hp", 85000));
		list.add(new studentstream(1, "hp", 15000));
		List<Integer> studentstream2 = list.stream().filter(p -> p.price > 30000).map(p -> p.price)
				.collect(Collectors.toList());
		System.out.println(studentstream2);
	}
}
