package list;

import java.util.HashMap;
import java.util.Map;

public class hashmap {
	public static void main(String[] args) {

		// Integer

//		HashMap<Integer, Integer> hMap = new HashMap<>();
//		hMap.put(1, 200);
//		hMap.put(2, 400);
//		hMap.put(3, 00);
//		hMap.put(4, 800);
//
//		for (Map.Entry<Integer, Integer> m : hMap.entrySet()) {
//			System.out.println(m.getKey() + " " + m.getValue());
//		}
//	}
//
//}

		// String and Integer

		HashMap<Integer, String> hMap = new HashMap<>();
		hMap.put(1, "Raveena");
		hMap.put(2, "Raphael");
		hMap.put(3, "Kiran");
		hMap.put(4, "Vincy");

		for (Map.Entry<Integer, String> m : hMap.entrySet()) {
			System.out.println(m.getKey() + " " + m.getValue());
		}
	}

}
