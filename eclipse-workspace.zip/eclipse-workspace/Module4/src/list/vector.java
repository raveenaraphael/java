package list;

import java.util.Iterator;
import java.util.Scanner;
import java.util.Vector;;

public class vector {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		Vector<Integer> list = new Vector<>();

		list.add(123);
		list.add(444);
		list.add(773);

		Iterator<Integer> itr = list.iterator();

		while (itr.hasNext()) {
			System.out.println(itr.next());
		}
		System.out.println(list.contains(789));

	}

}
