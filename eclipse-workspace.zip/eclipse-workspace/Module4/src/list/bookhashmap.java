package list;

public class bookhashmap {
	int id;
	String name;

	public bookhashmap(int id, String name) {
		this.id = id;
		this.name = name;

	}

	public String toString() {
		return id + " " + " " + name;

	}
}
