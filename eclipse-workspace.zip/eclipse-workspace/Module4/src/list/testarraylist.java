package list;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Scanner;
import java.util.Set;

public class testarraylist {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		ArrayList<String> list = new ArrayList<String>();

		list.add("apple");
		list.add("orange");
		list.add("mango");
		list.add("orange");
		list.add("banana");

		Iterator<String> itr = list.iterator();
		System.out.println("Iterator Elements");
		while (itr.hasNext()) {
			System.out.println(itr.next());

		}

		System.out.println("--------------------------------");

		int s = list.size() - 1;
		list.remove(s);

		for (String d : list) {

			System.out.println(d);
		}

		System.out.println("--------------------------------");

		/////////// search

		System.out.println(list.contains("apple"));
		if (true) {
			System.out.println("apple in the array");
		} else {
			System.out.println("apple is not in  array");
		}

//		String search = sc.next();
//
//		for (String i : list) {
//
//			if (i.equals(search)) {
//
//				System.out.println("Search element = " + i);
//
//			}
//
//		}
		System.out.println("--------------------------------");

		///// reverse
		System.out.println("Reverse elements");
		Collections.reverse(list);
		System.out.println(list);
		System.out.println("--------------------------------");
		///// sort
		System.out.println("Sorted elements");
		Collections.sort(list);
		System.out.println(list);
		System.out.println("--------------------------------");
		///// duplication
		System.out.println("Duplication Element Removed");
		Set<String> list1 = new HashSet<>(list);
		for (String d : list1) {

			System.out.println(d);
		}

	}

}
