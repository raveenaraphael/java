package list;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

public class comparatablemain {
	public static void main(String[] args) {
		ArrayList<comparatable> al = new ArrayList<comparatable>();
		al.add(new comparatable(1, "rav", 22));
		al.add(new comparatable(2, "laveena", 24));
		al.add(new comparatable(3, " xaj", 26));
		Comparator<comparatable> cm = Comparator.comparing(comparatable::getname);
		Collections.sort(al, cm);
		System.out.println("Sorting by name");
		for (comparatable st : al) {
			System.out.println(st);

		}
		Comparator<comparatable> cm1 = Comparator.comparing(comparatable::getage);
		Collections.sort(al, cm1);
		System.out.println("Sorting by name");
		for (comparatable st : al) {
			System.out.println(st);

		}
	}
}
