package list;

public class comparatable {
	int rollno;
	String name;
	int age;

	comparatable(int rollno, String name, int age) {
		this.rollno = rollno;
		this.name = name;
		this.age = age;
	}

	public int getRollno() {
		return rollno;
	}

	public void setrollno(int rollno) {
		this.rollno = rollno;
	}

	public String getname() {
		return name;
	}

	public void setname(String name) {
		this.name = name;
	}

	public int getage() {
		return age;
	}

	public void setage(int age) {
		this.age = age;
	}

	public String toString() {
		return "comparatable rollno=" + rollno + ",name=" + name + ",age=" + age;

	}
}