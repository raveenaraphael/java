package list;

public class compparablefunctional implements Comparable<compparablefunctional> {
	int rollno;
	String name;
	int age;

	compparablefunctional(int rollno, String name, int age) {
		this.rollno = rollno;
		this.name = name;
		this.age = age;
	}

	@Override
	public int compareTo(compparablefunctional st) {
		// TODO Auto-generated method stub
		if (rollno == st.rollno) {
			return 0;
		} else if (rollno > st.rollno) {
			return 1;

		} else {
			return -1;

		}

	}
}
