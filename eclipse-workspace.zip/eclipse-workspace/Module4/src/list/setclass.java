package list;

import java.util.HashSet;
import java.util.Iterator;
import java.util.Scanner;

public class setclass {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		HashSet<Integer> list = new HashSet<>();

		list.add(123);
		list.add(444);
		list.add(773);
		list.add(444);
		Iterator<Integer> itr = list.iterator();

		while (itr.hasNext()) {
			System.out.println(itr.next());
			System.out.println("hashcode=" + list.hashCode());

		}
//
//		for (int i : list) {
//			System.out.println(i);
//		}

	}

}
