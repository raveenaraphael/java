package list;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class streaming {
	public static void main(String[] args) {
		ArrayList<Integer> list = new ArrayList<>();
		list.add(50);
		list.add(40);
		list.add(10);
		System.out.println("list 1");

		for (int i : list) {
			System.out.println(i);
		}
		// multiply by 10

		List<Integer> li = list.stream().map(x -> x * 10).collect(Collectors.toList());
		System.out.println("list 2");
		for (int i : li) {
			System.out.println(i);
		}

	}
}
