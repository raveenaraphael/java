package list;

import java.util.Iterator;
import java.util.LinkedList;
import java.util.Scanner;

public class linkedlistinteger {

	// integer

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		LinkedList<Integer> list = new LinkedList<Integer>();

		list.add(123);

		list.add(678);

		list.add(980);

		// list.removeFirst();

		// list.removeLast();

		// list.clear();

		// Iterator<Integer> itr = list.iterator();
		Iterator<Integer> itr = list.descendingIterator();
		while (itr.hasNext()) {
			System.out.println(itr.next());
		}

	}

}
