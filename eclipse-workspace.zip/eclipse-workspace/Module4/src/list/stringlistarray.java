package list;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;

public class stringlistarray {
	public static void main(String[] args) {
		ArrayList<String> list = new ArrayList<String>();
		// List<Integer> li = new ArrayList<>();

		list.add("raveena");
		list.add("tyuihffv");
		list.add("rtuhg");

		System.out.println(list);

		Collections.sort(list);
		// for (int i : list) {
		// System.out.println(i);
		// }

		Iterator<String> iterator = list.iterator();
		while (iterator.hasNext()) {
			System.out.println(iterator.next());

		}

	}
}
