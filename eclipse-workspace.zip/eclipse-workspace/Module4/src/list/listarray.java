package list;

//import java.awt.List;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;

public class listarray {
	public static void main(String[] args) {
		ArrayList<Integer> list = new ArrayList<Integer>();
		// List<Integer> li = new ArrayList<>();

		list.add(1);
		list.add(7);
		list.add(3);

		System.out.println(list);
		Collections.sort(list);
		// for (int i : list) {
		// System.out.println(i);
		// }

		Iterator<Integer> iterator = list.iterator();
		while (iterator.hasNext()) {
			System.out.println(iterator.next());
		}

	}
}
