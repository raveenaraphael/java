package list;

import java.util.Scanner;
import java.util.Stack;

public class stackmain {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		Stack<stack> bk = new Stack<stack>();

		bk.push(new stack(12, 45, "gyu", " hhh", "ghjj"));
		bk.add(new stack(2, 45, "gyu", " hhh", "ghjj"));

		for (stack std : bk) {
			System.out.println(std);

		}
	}

}
