package list;

import java.util.HashSet;
import java.util.Scanner;

public class booksetmain {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		HashSet<bookset> bk = new HashSet<bookset>();

		bk.add(new bookset(1, "raveena"));
		bk.add(new bookset(2, "kiran"));
		bk.add(new bookset(2, "kiran"));
		bk.add(new bookset(1, "raveena"));

		for (bookset std : bk) {
			System.out.println(std);

		}
	}

}
