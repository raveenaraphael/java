package comparisonoperatorpkg;

public class compclass {
	public static void main(String[] args) {
		int a =10;
		int b=5;
            a+=2;
			a-=2;
			a*=2;
			a/=2;
			
			a--;
			a++;
			
	
			
			
			
			System.out.println(false&&false);
			System.out.println(false&&true);
			System.out.println(true&&false);
			System.out.println(true&&true);
			
			
			
			System.out.println(false||false);
			System.out.println(false||true);
			System.out.println(true||false);
			System.out.println(true||true);
			
			System.out.println(!false);
			System.out.println(!true);

			
			
			System.out.println(a);
			//System.out.println(c);
	}

}
