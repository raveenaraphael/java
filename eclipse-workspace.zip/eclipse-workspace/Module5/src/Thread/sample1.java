package Thread;

public class sample1 implements Runnable {

	public void run() {
		System.out.println("Thread Running");
	}

	public static void main(String[] args) {
		sample1 t1 = new sample1();
		Thread t = new Thread(t1);
		t.start();
	}

}
