package file;

import java.io.BufferedWriter;
import java.io.FileWriter;

public class seqbuffoutput {
	public static void main(String[] args) {
		try {

			FileWriter fW = new FileWriter("text20.txt");
			BufferedWriter bf = new BufferedWriter(fW);
			String s = "hello Kiran";

			fW.write(s);
			fW.close();
			System.out.println("success");

		} catch (Exception e) {
			// TODO: handle exception
			System.out.println(e);
		}
	}
}
