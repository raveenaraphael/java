package file;

import java.io.CharArrayWriter;
import java.io.FileWriter;

public class chararraywriter {

	public static void main(String[] args) {
		try {

			FileWriter fW = new FileWriter("kiran.txt");
			String s = "hello Kiran";
			CharArrayWriter cg = new CharArrayWriter();

			fW.write(s);
			fW.close();
			System.out.println("success");

		} catch (Exception e) {
			// TODO: handle exception
			System.out.println(e);
		}
	}
}
