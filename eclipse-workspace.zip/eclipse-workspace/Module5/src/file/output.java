package file;

import java.io.FileOutputStream;

public class output {
	public static void main(String[] args) {
		try {
			// FileOutputStream out = new FileOutputStream("text.txt");
			FileOutputStream outli = new FileOutputStream("raveena.txt");
//			out.write(67);
//			out.close();
			outli.write(80);
			outli.close();
			System.out.println("success");
		} catch (Exception e) {
			// TODO: handle exception
			System.out.println(e);
		}
	}
}
