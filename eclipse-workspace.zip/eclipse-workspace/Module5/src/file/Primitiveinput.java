package file;

import java.io.DataInputStream;
import java.io.FileInputStream;

public class Primitiveinput {
	public static void main(String[] args) {
		try {

			FileInputStream out = new FileInputStream("text14.txt");
			DataInputStream dout = new DataInputStream(out);
			System.out.println(dout.readInt());

			// System.out.println("sucess");

		} catch (Exception e) {
			// TODO: handle exception
			System.out.println(e);
		}
	}
}
