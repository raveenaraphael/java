package file;

import java.io.ByteArrayOutputStream;
import java.io.FileOutputStream;

public class Multipleoutputstream {
	public static void main(String[] args) {
		try {

			FileOutputStream outli = new FileOutputStream("text14.txt");

			FileOutputStream out = new FileOutputStream("text15.txt");
			ByteArrayOutputStream bout = new ByteArrayOutputStream();
			String s = "Welcome";
			byte b[] = s.getBytes();
			bout.write(b);
			bout.writeTo(out);
			bout.writeTo(outli);
			bout.flush();
			outli.close();
			System.out.println("success");
		} catch (Exception e) {
			// TODO: handle exception
			System.out.println(e);
		}
	}

}
