package file;

import java.io.CharArrayReader;
import java.io.FileReader;

public class chararrayreader {
	public static void main(String[] args) {
		try {

			FileReader fW = new FileReader("text14.txt");
			char[] ca = fW.toString().toCharArray();
			CharArrayReader bf = new CharArrayReader(ca);
			int i;
			while ((i = fW.read()) != -1) {
				System.out.print((char) i);
			}

		} catch (Exception e) {
			// TODO: handle exception
			System.out.println(e);
		}
	}
}
