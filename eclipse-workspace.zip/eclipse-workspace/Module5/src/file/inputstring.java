package file;

import java.io.FileInputStream;

public class inputstring {
	public static void main(String[] args) {
		try {

			FileInputStream outli = new FileInputStream("C://tex11t.txt");

//		
			int i;
			while ((i = outli.read()) != -1) {
				System.out.print((char) i);
			}
			// System.out.println("success");
		} catch (Exception e) {
			// TODO: handle exception
			System.out.println(e);
		}
	}
}
