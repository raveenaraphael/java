package file;

import java.io.FileOutputStream;

public class stringoutput {
	public static void main(String[] args) {
		try {

			FileOutputStream outli = new FileOutputStream("C://Users//Public//tex11t.txt");
			String s = "Welcome to I/o";
			byte b[] = s.getBytes();
			outli.write(b);
			outli.close();
			System.out.println("success");
		} catch (Exception e) {
			// TODO: handle exception
			System.out.println(e);
		}
	}
}
