package file;

import java.io.FileInputStream;
import java.io.SequenceInputStream;

public class multiplefiles {
	public static void main(String[] args) {
		try {

			FileInputStream outli = new FileInputStream("tex11t.txt");
			FileInputStream out = new FileInputStream("raveena.txt");

			SequenceInputStream sin = new SequenceInputStream(outli, out);
//		
			int i;
			while ((i = sin.read()) != -1) {
				System.out.print((char) i);
			}
			// System.out.println("success");
		} catch (Exception e) {
			// TODO: handle exception
			System.out.println(e);
		}
	}
}
