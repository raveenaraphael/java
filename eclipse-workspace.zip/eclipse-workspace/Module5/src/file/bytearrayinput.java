package file;

import java.io.ByteArrayInputStream;

public class bytearrayinput {
	public static void main(String[] args) {
		try {

			String s = "heloooo";
			byte b[] = s.getBytes();
			ByteArrayInputStream bout = new ByteArrayInputStream(b);
			int i = 0;
			while ((i = bout.read()) != -1) {
				System.out.print((char) i);
			}
			// System.out.println("success");
		} catch (Exception e) {
			// TODO: handle exception
			System.out.println(e);
		}
	}

}
