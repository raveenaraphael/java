package file;

import java.io.BufferedOutputStream;
import java.io.FileOutputStream;

public class bufferoutputstream {

	public static void main(String[] args) {
		try {

			FileOutputStream outli = new FileOutputStream("tex11t.txt");
			BufferedOutputStream bout = new BufferedOutputStream(outli);
			String s = "Welcome to I/o";
			byte b[] = s.getBytes();
			bout.write(b);
			bout.flush();
			outli.close();
			System.out.println("success");
		} catch (Exception e) {
			// TODO: handle exception
			System.out.println(e);
		}
	}

}
