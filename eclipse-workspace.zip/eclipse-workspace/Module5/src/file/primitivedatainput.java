package file;

import java.io.DataOutputStream;
import java.io.FileOutputStream;

public class primitivedatainput {

	public static void main(String[] args) {
		try {

			FileOutputStream out = new FileOutputStream("text16.txt");
			DataOutputStream dout = new DataOutputStream(out);

			dout.writeInt(987);
			out.close();

			System.out.println("sucess");

		} catch (Exception e) {
			// TODO: handle exception
			System.out.println(e);
		}
	}
}
