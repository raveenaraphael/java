package file;

import java.io.FileWriter;

public class stringwrite {
	public static void main(String[] args) {
		try {

			FileWriter fW = new FileWriter("text14.txt");
			String s = "hello raveena";

			fW.write(s);
			fW.close();
			System.out.println("success");

		} catch (Exception e) {
			// TODO: handle exception
			System.out.println(e);
		}
	}
}
