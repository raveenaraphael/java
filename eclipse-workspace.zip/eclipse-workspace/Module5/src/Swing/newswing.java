package Swing;

import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JRadioButton;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;

public class newswing extends JFrame {

	private JPanel contentPane;
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_2;
	private JTextField textField_3;
	private JTextField textField_4;
	private JPasswordField passwordField;
	private JRadioButton rdbtnOthers;
	private JRadioButton rdbtnMale;
	private JRadioButton rdbtnFemale;
	private final ButtonGroup buttonGroup = new ButtonGroup();

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					newswing frame = new newswing();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public newswing() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 672, 508);
		contentPane = new JPanel();
		contentPane.setBackground(Color.PINK);
		contentPane.setForeground(new Color(0, 255, 0));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		// JRadioButton rdbtnOthers, rdbtnMale, rdbtnFemale;

		JLabel lblRegistrationForm = new JLabel("Registration Form");
		lblRegistrationForm.setFont(new Font("Tahoma", Font.PLAIN, 16));
		lblRegistrationForm.setBackground(Color.RED);
		lblRegistrationForm.setForeground(Color.RED);
		lblRegistrationForm.setBounds(257, 11, 159, 40);
		contentPane.add(lblRegistrationForm);

		JLabel lblNewLabel = new JLabel("Name :");
		lblNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 17));
		lblNewLabel.setBounds(47, 133, 83, 40);
		contentPane.add(lblNewLabel);

		JLabel lblPhno = new JLabel("Ph.No:");
		lblPhno.setFont(new Font("Tahoma", Font.PLAIN, 17));
		lblPhno.setBounds(47, 184, 83, 21);
		contentPane.add(lblPhno);

		JLabel lblNewLabel_1 = new JLabel("Address:");
		lblNewLabel_1.setFont(new Font("Tahoma", Font.PLAIN, 17));
		lblNewLabel_1.setBounds(47, 216, 71, 32);
		contentPane.add(lblNewLabel_1);

		JLabel lblNewLabel_2 = new JLabel("Job :");
		lblNewLabel_2.setFont(new Font("Tahoma", Font.PLAIN, 17));
		lblNewLabel_2.setBounds(47, 250, 71, 32);
		contentPane.add(lblNewLabel_2);

		textField = new JTextField();
		textField.setBounds(127, 146, 229, 21);
		contentPane.add(textField);
		textField.setColumns(10);

		textField_1 = new JTextField();
		textField_1.setBounds(127, 187, 229, 21);
		contentPane.add(textField_1);
		textField_1.setColumns(10);

		textField_2 = new JTextField();
		textField_2.setBounds(128, 224, 228, 21);
		contentPane.add(textField_2);
		textField_2.setColumns(10);

		textField_3 = new JTextField();
		textField_3.setBounds(127, 259, 229, 23);
		contentPane.add(textField_3);
		textField_3.setColumns(10);

		JButton btnSubmit = new JButton("Submit");
		btnSubmit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {

				String Name = textField.getText();
				String PhNo = textField_1.getText();
				String Address = textField_2.getText();
				String Job = textField_3.getText();
				String Email = textField_4.getText();
				char[] Password = passwordField.getPassword();

				String sex = " ";
				if (rdbtnMale.isSelected()) {
					sex = "Male";
				} else if (rdbtnFemale.isSelected()) {
					sex = "Female";
				} else if (rdbtnOthers.isSelected()) {
					sex = "Others";
				}

				new newswing2ndPage(Name, PhNo, Address, Job, Email, sex, Password);
			}
		});
		btnSubmit.setForeground(Color.GREEN);
		btnSubmit.setBackground(Color.RED);
		btnSubmit.setFont(new Font("Tahoma", Font.PLAIN, 17));
		btnSubmit.setBounds(463, 435, 89, 23);
		contentPane.add(btnSubmit);

		JLabel lblEmail = new JLabel("Email :");
		lblEmail.setFont(new Font("Tahoma", Font.PLAIN, 17));
		lblEmail.setBounds(47, 301, 56, 14);
		contentPane.add(lblEmail);

		textField_4 = new JTextField();
		textField_4.setBounds(127, 298, 229, 21);
		contentPane.add(textField_4);
		textField_4.setColumns(10);

		JLabel lblPassword = new JLabel("Password :");
		lblPassword.setFont(new Font("Tahoma", Font.PLAIN, 17));
		lblPassword.setBounds(47, 344, 108, 21);
		contentPane.add(lblPassword);

		passwordField = new JPasswordField();
		passwordField.setBounds(127, 347, 229, 20);
		contentPane.add(passwordField);

		JLabel lblGender = new JLabel("Gender :");
		lblGender.setFont(new Font("Tahoma", Font.PLAIN, 17));
		lblGender.setBounds(47, 391, 84, 14);
		contentPane.add(lblGender);

		rdbtnFemale = new JRadioButton("Female");
		buttonGroup.add(rdbtnFemale);
		rdbtnFemale.setBounds(127, 390, 109, 23);
		contentPane.add(rdbtnFemale);

		rdbtnMale = new JRadioButton("Male");
		buttonGroup.add(rdbtnMale);
		rdbtnMale.setBounds(273, 390, 109, 23);
		contentPane.add(rdbtnMale);

		rdbtnOthers = new JRadioButton("Others");
		buttonGroup.add(rdbtnOthers);
		rdbtnOthers.setBounds(417, 390, 109, 23);
		contentPane.add(rdbtnOthers);
	}
}
