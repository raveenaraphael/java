package Swing;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Arrays;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;

public class newswing2ndPage extends JFrame {

	private JPanel contentPane;
	private JTextField textField;
	private JPasswordField passwordField;

	String Name1, PhNo1, Address1, Job1, Email1, sex1;
	char[] Password1;
	private JLabel label;

	public newswing2ndPage(String Name, String PhNo, String Address, String Job, String Email, String sex,
			char[] password) {

		Name1 = Name;
		PhNo1 = PhNo;
		Address1 = Address;
		Job1 = Job;
		Email1 = Email;
		Password1 = password;
		sex1 = sex;

		setVisible(true);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 610, 439);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(153, 204, 255));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);

		JLabel lblNewLabel = new JLabel("Email :");
		lblNewLabel.setBounds(88, 126, 82, 21);
		lblNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 17));
		contentPane.add(lblNewLabel);

		textField = new JTextField();
		textField.setBounds(184, 130, 376, 18);
		contentPane.add(textField);
		textField.setColumns(10);

		JLabel lblPassword = new JLabel("Password :");
		lblPassword.setFont(new Font("Tahoma", Font.PLAIN, 17));
		lblPassword.setBounds(88, 203, 82, 14);
		contentPane.add(lblPassword);

		passwordField = new JPasswordField();
		passwordField.setBounds(193, 203, 367, 20);
		contentPane.add(passwordField);

		JButton btnLogin = new JButton("Login");
		btnLogin.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String email = textField.getText();
				char[] password = passwordField.getPassword();
//				System.out.println(password);
//				System.out.println(email);
				if (email.equals(Email1) && Arrays.equals(password, Password1)) {
					label.setText("Login successful");
					new page3(Name1, PhNo1, Address1, Job1, Email1, sex1, Password1);
				} else {
					label.setText("Invalid");

				}
				// new page3();
			}
		});
		btnLogin.setBackground(new Color(0, 255, 255));
		btnLogin.setForeground(new Color(255, 0, 0));
		btnLogin.setFont(new Font("Tahoma", Font.PLAIN, 17));
		btnLogin.setBounds(311, 308, 89, 23);
		contentPane.add(btnLogin);

		label = new JLabel();
		label.setBounds(184, 342, 359, 35);
		contentPane.add(label);
	}
}
