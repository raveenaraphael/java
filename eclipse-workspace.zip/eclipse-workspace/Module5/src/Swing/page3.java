package Swing;

import java.awt.Color;
import java.awt.Font;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

public class page3 extends JFrame {

	private JPanel contentPane;

	/**
	 * Launch the application.
	 */

	/**
	 * Create the frame.
	 */
	public page3(String Name, String PhNo, String Address, String Job, String Email, String sex, char[] password) {
		setVisible(true);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 594, 523);
		contentPane = new JPanel();
		contentPane.setForeground(new Color(0, 0, 0));
		contentPane.setBackground(new Color(0, 255, 255));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);

		JLabel l1 = new JLabel("Name =" + Name);
		l1.setForeground(new Color(0, 51, 0));
		l1.setBackground(new Color(204, 255, 255));
		l1.setBounds(210, 136, 225, 32);
		contentPane.add(l1);

		JLabel l2 = new JLabel("PhNo =" + PhNo);
		l2.setBounds(210, 179, 209, 41);
		contentPane.add(l2);

		JLabel l3 = new JLabel("Address =" + Address);
		l3.setBounds(210, 231, 219, 41);
		contentPane.add(l3);

		JLabel lblDetails = new JLabel("Details");
		lblDetails.setFont(new Font("Tahoma", Font.PLAIN, 17));
		lblDetails.setBounds(255, 11, 81, 53);
		contentPane.add(lblDetails);

		JLabel l4 = new JLabel("Job =" + Job);
		l4.setBounds(216, 283, 219, 41);
		contentPane.add(l4);

		JLabel l5 = new JLabel("Email =" + Email);
		l5.setBounds(210, 334, 209, 41);
		contentPane.add(l5);

		JLabel l6 = new JLabel("password =" + password);
		l6.setBounds(210, 386, 225, 43);
		contentPane.add(l6);

		JLabel l7 = new JLabel("Gender =" + sex);
		l7.setBounds(210, 445, 144, 14);
		contentPane.add(l7);
	}

}
