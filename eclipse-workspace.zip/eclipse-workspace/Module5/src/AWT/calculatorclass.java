package AWT;

import java.awt.Button;
import java.awt.Frame;
import java.awt.Label;
import java.awt.TextArea;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class calculatorclass implements ActionListener {
	Label l1, l2, l3, l4;
	Button b, b1, b3, b2, b4;
	TextArea t1, t2;
	int z;

	public calculatorclass() {
		Frame f = new Frame();
		f.setSize(500, 500);
		f.setLayout(null);
		f.setVisible(true);

		l1 = new Label("Num1");
		l1.setBounds(50, 50, 100, 50);
		f.add(l1);

		t1 = new TextArea();
		t1.setBounds(150, 50, 100, 50);
		f.add(t1);

		l2 = new Label("Num2");
		l2.setBounds(50, 150, 100, 50);
		f.add(l2);

		t2 = new TextArea();
		t2.setBounds(180, 150, 100, 50);
		f.add(t2);

		b = new Button("+");
		b.setBounds(20, 250, 100, 30);
		b.addActionListener(this);
		f.add(b);

		b1 = new Button("-");
		b1.setBounds(40, 300, 100, 30);
		b1.addActionListener(this);
		f.add(b1);

		b3 = new Button("*");
		b3.setBounds(60, 350, 100, 30);
		b3.addActionListener(this);
		f.add(b3);

		b2 = new Button("/");
		b2.setBounds(80, 400, 100, 30);
		b2.addActionListener(this);
		f.add(b2);

		l3 = new Label("Sum");
		l3.setBounds(100, 450, 100, 50);
		f.add(l3);

		l4 = new Label();
		l4.setBounds(150, 500, 100, 50);
		f.add(l4);

	}

	public void actionPerformed(ActionEvent e) {

		String x = t1.getText();
		int z = Integer.parseInt(x);
		String y = t2.getText();
		int a = Integer.parseInt(y);
		// System.out.println(t1.getText());

		if (e.getSource() == b) {
			//
			int d = z + a;

			// l4.setText(String.valueOf(d));
			l4.setText(Integer.toString(d));
		}
		if (e.getSource() == b1) {
			int d = z - a;

			// l4.setText(String.valueOf(d));
			l4.setText(Integer.toString(d));
		}
		if (e.getSource() == b3) {
			int d = z * a;

			// l4.setText(String.valueOf(d));
			l4.setText(Integer.toString(d));
		}
		if (e.getSource() == b2) {
			int d = z / a;

			// l4.setText(String.valueOf(d));
			l4.setText(Integer.toString(d));

		}
	}

	public static void main(String[] args) {
		new calculatorclass();
	}
}
