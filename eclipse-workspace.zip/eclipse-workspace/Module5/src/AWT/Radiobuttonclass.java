package AWT;

import java.awt.Button;
import java.awt.Checkbox;
import java.awt.CheckboxGroup;
import java.awt.Frame;
import java.awt.Label;
import java.awt.TextField;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Radiobuttonclass implements ActionListener {

	Label l1, l2;
	TextField t1;
	Button b, b1;
	Checkbox c1, c2, c3;
	CheckboxGroup ch;

	public Radiobuttonclass() {

		Frame f = new Frame();
		f.setSize(500, 500);
		f.setLayout(null);
		f.setVisible(true);

		l1 = new Label("Name");
		l1.setBounds(50, 50, 100, 50);
		f.add(l1);
		ch = new CheckboxGroup();

		c1 = new Checkbox("Male", true, ch);
		c1.setBounds(50, 90, 100, 30);
		f.add(c1);

		c2 = new Checkbox("Female", false, ch);
		c2.setBounds(50, 110, 100, 30);
		f.add(c2);

		c3 = new Checkbox("others", false, ch);
		c3.setBounds(50, 130, 100, 30);
		f.add(c3);

		b = new Button("Submit");
		b.setBounds(200, 450, 100, 30);
		b.addActionListener(this);
		f.add(b);
	}

	public void actionPerformed(ActionEvent e) {
		String sex = " ";
		if (c1.getState() == true) {
			sex = "Male";
		}
		if (c2.getState() == true) {
			sex = "Female";
		}
		if (c3.getState() == true) {
			sex = "others";
		}
		System.out.println(sex);
	}

}
