package AWT;

import java.awt.Button;
import java.awt.Color;
import java.awt.Frame;
import java.awt.Label;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class calculatorclassnew implements ActionListener {

	Button b, b1, b3, b2, b4, b5, b6, b7, b8, b9, b10, b11, b12, b13, b14, b15, b16, b17, b18, b19;
	Label t1;
	String operator;
	double num1, num2, result;

	public calculatorclassnew() {
		Frame f = new Frame();
		f.setSize(400, 500);
		f.setLayout(null);
		f.setBackground(Color.YELLOW);
		f.setVisible(true);

		t1 = new Label();
		t1.setBounds(50, 100, 300, 70);
		t1.setBackground(Color.LIGHT_GRAY);
		f.add(t1);

		b = new Button("CE");
		b.setBounds(50, 180, 50, 30);
		b.addActionListener(this);
		f.add(b);

		b1 = new Button("Back");
		b1.setBounds(120, 180, 50, 30);
		b1.addActionListener(this);
		f.add(b1);

		b2 = new Button("%");
		b2.setBounds(200, 180, 50, 30);
		b2.addActionListener(this);
		f.add(b2);

		b3 = new Button("/");
		b3.setBounds(280, 180, 50, 30);
		b3.addActionListener(this);
		f.add(b3);

		b4 = new Button("7");
		b4.setBounds(50, 220, 50, 30);
		b4.addActionListener(this);
		f.add(b4);

		b5 = new Button("8");
		b5.setBounds(120, 220, 50, 30);
		b5.addActionListener(this);
		f.add(b5);

		b6 = new Button("9");
		b6.setBounds(200, 220, 50, 30);
		b6.addActionListener(this);
		f.add(b6);

		b7 = new Button("*");
		b7.setBounds(280, 220, 50, 30);
		b7.addActionListener(this);
		f.add(b7);

		b8 = new Button("4");
		b8.setBounds(50, 260, 50, 30);
		b8.addActionListener(this);
		f.add(b8);

		b9 = new Button("5");
		b9.setBounds(120, 260, 50, 30);
		b9.addActionListener(this);
		f.add(b9);

		b10 = new Button("6");
		b10.setBounds(200, 260, 50, 30);
		b10.addActionListener(this);
		f.add(b10);

		b11 = new Button("-");
		b11.setBounds(280, 260, 50, 30);
		b11.addActionListener(this);
		f.add(b11);

		b12 = new Button("1");
		b12.setBounds(50, 300, 50, 30);
		b12.addActionListener(this);
		f.add(b12);

		b13 = new Button("2");
		b13.setBounds(120, 300, 50, 30);
		b13.addActionListener(this);
		f.add(b13);

		b14 = new Button("3");
		b14.setBounds(200, 300, 50, 30);
		b14.addActionListener(this);
		f.add(b14);

		b15 = new Button("+");
		b15.setBounds(280, 300, 50, 30);
		b15.addActionListener(this);
		f.add(b15);

		b16 = new Button("+/-");
		b16.setBounds(50, 340, 50, 30);
		b16.addActionListener(this);
		f.add(b16);

		b17 = new Button("0");
		b17.setBounds(120, 340, 50, 30);
		b17.addActionListener(this);
		f.add(b17);

		b18 = new Button(".");
		b18.setBounds(200, 340, 50, 30);
		b18.addActionListener(this);
		f.add(b18);

		b19 = new Button("=");
		b19.setBounds(280, 340, 50, 30);
		b19.addActionListener(this);
		f.add(b19);

	}

	public void actionPerformed(ActionEvent e) {

		String y, x;

///////// numbers
		if (e.getSource() == b17) {
			y = t1.getText();
			x = y + "0";
			t1.setText(x);
		}

		if (e.getSource() == b12) {
			y = t1.getText();
			x = y + "1";
			t1.setText(x);
		}
		if (e.getSource() == b13) {
			y = t1.getText();
			x = y + "2";
			t1.setText(x);
		}

		if (e.getSource() == b14) {
			y = t1.getText();
			x = y + "3";
			t1.setText(x);
		}

		if (e.getSource() == b8) {
			y = t1.getText();
			x = y + "4";
			t1.setText(x);
		}

		if (e.getSource() == b9) {
			y = t1.getText();
			x = y + "5";
			t1.setText(x);
		}

		if (e.getSource() == b10) {
			y = t1.getText();
			x = y + "6";
			t1.setText(x);
		}

		if (e.getSource() == b4) {
			y = t1.getText();
			x = y + "7";
			t1.setText(x);
		}

		if (e.getSource() == b5) {
			y = t1.getText();
			x = y + "8";
			t1.setText(x);
		}

		if (e.getSource() == b6) {
			y = t1.getText();
			x = y + "9";
			t1.setText(x);
		}
		if (e.getSource() == b) {
			t1.setText("");

		}

		// Back
		if (e.getSource() == b1) {
			String text = t1.getText();
			if (text.length() > 0) {
				t1.setText(text.substring(0, text.length() - 1));
			}
		}

		if (e.getSource() == b2) {
			num1 = Double.parseDouble(t1.getText());
			operator = "%";
			t1.setText("");
		}

		if (e.getSource() == b3) {
			num1 = Double.parseDouble(t1.getText());
			operator = "/";
			t1.setText("");
		}

		if (e.getSource() == b7) {
			num1 = Double.parseDouble(t1.getText());
			operator = "*";
			t1.setText("");
		}

		if (e.getSource() == b11) {
			num1 = Double.parseDouble(t1.getText());
			operator = "-";
			t1.setText("");
		}

		if (e.getSource() == b15) {
			num1 = Double.parseDouble(t1.getText());
			operator = "+";
			t1.setText("");
		}

		if (e.getSource() == b18) {
			t1.setText(t1.getText() + ".");
		}
//negative
		if (e.getSource() == b16) {
			double temp = Double.parseDouble(t1.getText());
			temp = temp * -1;
			t1.setText(String.valueOf(temp));
		}

//operations
		if (e.getSource() == b19) {
			num2 = Double.parseDouble(t1.getText());
			switch (operator) {
			case "+":
				result = num1 + num2;
				break;
			case "-":
				result = num1 - num2;
				break;
			case "*":
				result = num1 * num2;
				break;
			case "/":
				result = num1 / num2;
				break;
			case "%":
				result = num1 % num2;
				break;
			}
			t1.setText(String.valueOf(result));
		}
	}

	public static void main(String[] args) {

		new calculatorclassnew();
	}

}
