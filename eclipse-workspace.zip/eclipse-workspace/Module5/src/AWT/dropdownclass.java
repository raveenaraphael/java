package AWT;

import java.awt.Button;
import java.awt.Choice;
import java.awt.Frame;
import java.awt.TextField;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class dropdownclass implements ActionListener {

	TextField t1;
	Button b, b1;

	Choice ch;

	public dropdownclass() {
		Frame f = new Frame();
		f.setSize(500, 500);
		f.setLayout(null);
		f.setVisible(true);

		ch = new Choice();
		ch.add("Kerala");
		ch.add("Tamilnadu");
		ch.add("Karnataka");
		ch.setBounds(150, 250, 100, 30);
		f.add(ch);

		b = new Button("Submit");
		b.setBounds(200, 450, 100, 30);
		b.addActionListener(this);
		f.add(b);
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		System.out.println(ch.getSelectedItem());
	}

	public static void main(String[] args) {
		new dropdownclass();
	}
}