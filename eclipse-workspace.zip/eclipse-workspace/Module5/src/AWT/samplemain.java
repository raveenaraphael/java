package AWT;

public class samplemain {
	public static void main(String[] args) {
		new sample1();
	}
}
