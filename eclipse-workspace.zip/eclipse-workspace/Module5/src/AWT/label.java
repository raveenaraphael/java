package AWT;

import java.awt.Button;
import java.awt.Frame;
import java.awt.Label;
import java.awt.TextArea;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class label implements ActionListener {
	Label l1, l2;
	Button b, b1;
	TextArea t1;

	public label() {
		Frame f = new Frame();
		f.setSize(500, 500);
		f.setLayout(null);
		f.setVisible(true);

		l1 = new Label("Name");
		l1.setBounds(50, 50, 100, 20);
		f.add(l1);

		t1 = new TextArea();
		t1.setBounds(100, 100, 100, 60);
		f.add(t1);

		b = new Button("Submit");
		b.setBounds(200, 450, 100, 30);
		b.addActionListener(this);
		f.add(b);

		b1 = new Button("button2");
		b1.setBounds(100, 200, 100, 30);
		b1.addActionListener(this);
		f.add(b1);

		l2 = new Label();
		l2.setBounds(250, 250, 100, 20);
		f.add(l2);

	}

	public void actionPerformed(ActionEvent e) {

		// System.out.println("clicked");

		String x = t1.getText();
		System.out.println(t1.getText());

		if (e.getSource() == b) {
			// System.out.println("botton1");
			l2.setText(x);
		}
		if (e.getSource() == b1) {
			System.out.println("botton2");
		}
	}

	public static void main(String[] args) {
		new label();
	}
}