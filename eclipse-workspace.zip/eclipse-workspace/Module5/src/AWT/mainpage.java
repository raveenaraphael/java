package AWT;

public class mainpage {
	public static void main(String[] args) {

		new page1();
	}

}
