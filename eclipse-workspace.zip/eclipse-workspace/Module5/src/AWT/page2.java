package AWT;

import java.awt.Button;
import java.awt.Color;
import java.awt.Frame;
import java.awt.Label;
import java.awt.TextField;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class page2 implements ActionListener {
	Label l2, l3, l4;
	Button b;
	TextField t2, t3;
	String Name1, Email1, Password1, State1, language1, sex1;

	public page2(String Name, String Email, String Password, String State, String language, String sex) {

		Name1 = Name;
		Email1 = Email;
		Password1 = Password;
		State1 = State;
		language1 = language;
		sex1 = sex;

		Frame f = new Frame();
		f.setSize(500, 500);
		f.setLayout(null);
		f.setBackground(Color.lightGray);
		f.setVisible(true);

		l2 = new Label("Email");
		l2.setBounds(50, 100, 100, 30);
		f.add(l2);

		t2 = new TextField();
		t2.setBounds(150, 100, 300, 30);
		f.add(t2);

		l3 = new Label("Password");
		l3.setBounds(50, 150, 100, 30);
		f.add(l3);

		t3 = new TextField();
		t3.setBounds(150, 150, 300, 30);
		f.add(t3);

		b = new Button("Login");
		b.setBounds(150, 250, 200, 30);
		b.setBackground(Color.CYAN);
		b.addActionListener(this);
		f.add(b);

		l4 = new Label();
		l4.setBounds(50, 550, 500, 30);
		f.add(l4);

	}

	public void actionPerformed(ActionEvent e) {

		String email = t2.getText();
		String password = t3.getText();

		if (email.equals(Email1) && password.equals(Password1)) {
			l4.setText("Login successful");
			new page3(Name1, Email1, Password1, State1, language1, sex1);
		} else {
			l4.setText("Invalid");

		}

	}

}
