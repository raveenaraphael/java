package AWT;

import java.awt.Frame;
import java.awt.Menu;
import java.awt.MenuBar;

public class menubar extends Frame {
	public menubar() {
		setSize(500, 500);
		setLayout(null);
		setVisible(true);

		MenuBar m = new MenuBar();
		Menu m1 = new Menu("File");
		Menu sb4 = new Menu("New");
		Menu new1 = new Menu("java Project");
		Menu new2 = new Menu("Project");
		Menu new3 = new Menu("Package");

		Menu sb1 = new Menu("open file");
		Menu sb2 = new Menu("open project");
		Menu sb3 = new Menu("Recent Files");

		Menu m2 = new Menu("Edit");
		Menu m3 = new Menu("Source");
		Menu m4 = new Menu("Refactor");
		Menu m5 = new Menu("Navigate");
		m.add(m1);
		m.add(m2);
		m.add(m3);
		m.add(m4);
		m.add(m5);
		m1.add(sb4);
		m1.add(sb1);
		m1.add(sb2);
		m1.add(sb3);
		sb4.add(new1);
		sb4.add(new2);
		sb4.add(new3);
		setMenuBar(m);

	}

	public static void main(String[] args) {
		new menubar();
	}
}