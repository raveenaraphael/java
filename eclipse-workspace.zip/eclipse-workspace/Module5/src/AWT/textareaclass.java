package AWT;

import java.awt.Button;
import java.awt.Frame;
import java.awt.TextArea;
import java.awt.TextField;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class textareaclass implements ActionListener {
	TextField t1;
	Button b, b1;
	TextArea ch;

	public textareaclass() {
		Frame f = new Frame();
		f.setSize(500, 500);
		f.setLayout(null);
		f.setVisible(true);

		ch = new TextArea();
		ch.setBounds(150, 250, 100, 500);
		f.add(ch);

		b = new Button("Submit");
		b.setBounds(200, 450, 100, 30);
		b.addActionListener(this);
		f.add(b);
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		System.out.println(ch.getText());
	}

	public static void main(String[] args) {
		new textareaclass();
	}
}
