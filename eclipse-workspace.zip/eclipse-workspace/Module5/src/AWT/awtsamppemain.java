package AWT;

public class awtsamppemain {
	public static void main(String[] args) {
		new awtsamppe();
	}
}
