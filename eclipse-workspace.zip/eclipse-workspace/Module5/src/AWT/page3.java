package AWT;

import java.awt.Color;
import java.awt.Frame;
import java.awt.Label;

public class page3 {
	Label l1, l2, l3, l4, l5, l6;

	public page3(String Name, String Email, String Password, String State, String language, String sex) {

		Frame f = new Frame();
		f.setSize(500, 500);
		f.setLayout(null);
		f.setBackground(Color.lightGray);
		f.setVisible(true);

		l1 = new Label("Name =" + Name);
		l1.setBounds(50, 100, 500, 30);
		f.add(l1);

		l2 = new Label("Email =" + Email);
		l2.setBounds(50, 150, 500, 30);
		f.add(l2);

		l3 = new Label("Password =" + Password);
		l3.setBounds(50, 200, 500, 30);
		f.add(l3);

		l4 = new Label("State =" + State);
		l4.setBounds(50, 250, 500, 30);
		f.add(l4);

		l5 = new Label("language =" + language);
		l5.setBounds(50, 300, 500, 30);
		f.add(l5);

		l6 = new Label("sex =" + sex);
		l6.setBounds(50, 350, 500, 30);
		f.add(l6);

	}
}