package AWT;

import java.awt.Button;
import java.awt.Frame;
import java.awt.List;
import java.awt.TextField;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class list implements ActionListener {

	TextField t1;
	Button b, b1;

	List ch;

	public list() {
		Frame f = new Frame();
		f.setSize(500, 500);
		f.setLayout(null);
		f.setVisible(true);

		ch = new List();
		ch.add("Kerala");
		ch.add("Tamilnadu");
		ch.add("Karnataka");
		ch.add("Delhi");
		ch.add("Mumbai");
		ch.add("Goa");
		ch.setBounds(150, 250, 100, 30);
		f.add(ch);

		b = new Button("Submit");
		b.setBounds(200, 450, 100, 30);
		b.addActionListener(this);
		f.add(b);
	}

	public void actionPerformed(ActionEvent e) {

		System.out.println(ch.getSelectedItem());
	}

	public static void main(String[] args) {
		new list();
	}
}
