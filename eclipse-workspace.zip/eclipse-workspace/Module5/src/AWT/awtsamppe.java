package AWT;

import java.awt.Frame;

public class awtsamppe extends Frame {
	public awtsamppe() {
		setSize(500, 500);
		setLayout(null);
		setVisible(true);
	}

}
