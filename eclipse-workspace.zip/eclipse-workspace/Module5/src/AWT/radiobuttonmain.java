package AWT;

public class radiobuttonmain {
	public static void main(String[] args) {
		new Radiobuttonclass();
	}
}
