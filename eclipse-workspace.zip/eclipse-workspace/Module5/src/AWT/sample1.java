package AWT;

import java.awt.Button;
import java.awt.Color;
import java.awt.Frame;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class sample1 implements ActionListener {

	public sample1() {
		Frame f = new Frame();
		f.setSize(500, 500);
		f.setLayout(null);
		f.setVisible(true);

		Button b = new Button("Submit");
		b.setBounds(100, 100, 80, 30);
		b.setBackground(Color.orange);
		b.addActionListener(this);
		f.add(b);

	}

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		new sample2();
	}
}