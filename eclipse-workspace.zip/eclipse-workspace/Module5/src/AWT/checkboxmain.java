package AWT;

public class checkboxmain {
	public static void main(String[] args) {
		new checkbox();
	}
}
