package AWT;

import java.awt.Button;
import java.awt.Color;
import java.awt.Frame;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class sample2 implements ActionListener {
	public sample2() {
		Frame f = new Frame();
		f.setSize(500, 500);
		f.setLayout(null);
		f.setVisible(true);

		Button b = new Button("Cancel");
		b.setBounds(100, 100, 80, 30);
		b.setBackground(Color.CYAN);
		f.add(b);

	}

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub

	}
}