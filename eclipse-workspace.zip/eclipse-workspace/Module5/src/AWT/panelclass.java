package AWT;

import java.awt.Button;
import java.awt.Color;
import java.awt.Frame;
import java.awt.Panel;

public class panelclass {
	panelclass() {
		Frame f = new Frame("Panel Example");
		Panel panel = new Panel();
		panel.setBounds(40, 80, 200, 200);
		panel.setBackground(Color.BLUE);

		Button b = new Button("Submit");
		b.setBounds(100, 100, 80, 30);
		b.setBackground(Color.orange);
		f.add(b);

		Button b1 = new Button("Cancel");
		b1.setBounds(100, 100, 80, 30);
		b1.setBackground(Color.GREEN);
		f.add(b1);

		panel.add(b);

		panel.add(b1);

		f.add(panel);
		f.setSize(400, 400);
		f.setLayout(null);
		f.setVisible(true);

	}

	public static void main(String[] args) {
		new panelclass();
	}
}
