package AWT;

import java.awt.Button;
import java.awt.Checkbox;
import java.awt.CheckboxGroup;
import java.awt.Color;
import java.awt.Frame;
import java.awt.Label;
import java.awt.List;
import java.awt.TextArea;
import java.awt.TextField;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class page1 implements ActionListener {
	Label l1, l2, l3, l4, l5, l6, l7, l8;
	Button b;
	TextField t1, t2, t3;
	TextArea ta;
	CheckboxGroup ch;
	List st;
	Checkbox c1, c2, c3, d1, d2, d3;

	public page1() {
		Frame f = new Frame();
		f.setSize(500, 500);
		f.setLayout(null);
		f.setBackground(Color.lightGray);
		f.setVisible(true);

		l1 = new Label("Name");
		l1.setBounds(50, 50, 100, 30);
		f.add(l1);

		t1 = new TextField();
		t1.setBounds(150, 50, 100, 30);
		f.add(t1);

		l2 = new Label("Email");
		l2.setBounds(50, 100, 100, 30);
		f.add(l2);

		t2 = new TextField();
		t2.setBounds(150, 100, 100, 30);
		f.add(t2);

		l3 = new Label("Password");
		l3.setBounds(50, 150, 100, 30);
		f.add(l3);

		t3 = new TextField();
		t3.setBounds(150, 150, 100, 30);
		f.add(t3);
///Gender

		ch = new CheckboxGroup();

		l4 = new Label("Gender");
		l4.setBounds(50, 200, 100, 30);
		f.add(l4);

		c1 = new Checkbox("Male", true, ch);
		c1.setBounds(200, 200, 100, 30);
		f.add(c1);

		c2 = new Checkbox("Female", false, ch);
		c2.setBounds(300, 200, 100, 30);
		f.add(c2);

		c3 = new Checkbox("others", false, ch);
		c3.setBounds(400, 200, 100, 30);
		f.add(c3);

////language

		l5 = new Label("Language");
		l5.setBounds(50, 250, 100, 30);
		f.add(l5);

		d1 = new Checkbox("Malayalam");
		d1.setBounds(200, 250, 100, 20);
		f.add(d1);

		d2 = new Checkbox("english");
		d2.setBounds(300, 250, 100, 20);
		f.add(d2);

		d3 = new Checkbox("hindi");
		d3.setBounds(400, 250, 100, 20);
		f.add(d3);

////State

		l6 = new Label("State");
		l6.setBounds(50, 300, 100, 30);
		f.add(l6);

		st = new List();
		st.add("Select");
		st.add("Kerala");
		st.add("Tamilnadu");
		st.add("Karnataka");
		st.add("Delhi");
		st.add("Mumbai");
		st.add("Goa");
		st.setBounds(200, 300, 100, 20);
		f.add(st);

///Address

		l7 = new Label("Address");
		l7.setBounds(50, 350, 100, 30);
		f.add(l7);

		ta = new TextArea();
		ta.setBounds(150, 350, 400, 100);
		f.add(ta);

		b = new Button("Submit");
		b.setBounds(250, 550, 300, 30);
		b.setBackground(Color.CYAN);
		b.addActionListener(this);
		f.add(b);

		l8 = new Label();
		l8.setBounds(650, 450, 100, 30);
		f.add(l8);
	}

	public void actionPerformed(ActionEvent e) {

		String Name = t1.getText();
		String Email = t2.getText();
		String Password = t3.getText();
		String Address = ta.getText();
		String State = st.getSelectedItem();
		String language = " ";
		if (d1.getState() == true) {
			language += "malayalam";
		}
		if (d2.getState() == true) {
			language += "English";
		}
		if (d3.getState() == true) {
			language += "hindi";
		}

		String sex = " ";
		if (c1.getState() == true) {
			sex = "Male";
		}
		if (c2.getState() == true) {
			sex = "Female";
		}
		if (c3.getState() == true) {
			sex = "others";
		}

		new page2(Name, Email, Password, State, language, sex);

	}

}