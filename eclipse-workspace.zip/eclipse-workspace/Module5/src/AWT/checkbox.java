package AWT;

import java.awt.Button;
import java.awt.Checkbox;
import java.awt.Frame;
import java.awt.Label;
import java.awt.TextField;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class checkbox implements ActionListener {
	Label l1, l2;
	TextField t1;
	Button b, b1;
	Checkbox c1, c2, c3;

	public checkbox() {
		Frame f = new Frame();
		f.setSize(500, 500);
		f.setLayout(null);
		f.setVisible(true);

		l1 = new Label("name");
		l1.setBounds(50, 50, 100, 50);
		f.add(l1);

		c1 = new Checkbox("Malayalam");
		c1.setBounds(50, 90, 100, 30);
		f.add(c1);

		c2 = new Checkbox("english");
		c2.setBounds(50, 110, 100, 30);
		f.add(c2);

		c3 = new Checkbox("hindi");
		c3.setBounds(50, 140, 100, 30);
		f.add(c3);

		b = new Button("Submit");
		b.setBounds(200, 450, 100, 30);
		b.addActionListener(this);
		f.add(b);
	}

	public void actionPerformed(ActionEvent e) {
		String language = " ";
		if (c1.getState() == true) {
			language += "malayalam";
		}
		if (c2.getState() == true) {
			language += "English";
		}
		if (c3.getState() == true) {
			language += "hindi";
		}
		System.out.println(language);
	}

}
