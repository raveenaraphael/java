package sumpkg;

import java.util.Scanner;

public class sumclass {
public static void main(String[] args) {
	System.out.println("Enter 1st number ");

	
	Scanner sc=new Scanner(System.in);
	int a =sc.nextInt();
	System.out.println(a);
	
	System.out.println("Enter 2nd number");
	Scanner cc=new Scanner(System.in);
	int b = cc.nextInt();
	System.out.println(b);
	
	int c = a+b;
	System.out.println("Sum ="+c);
}
}
