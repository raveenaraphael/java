package array;

import java.util.Scanner;

public class checksame {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
	        Scanner sc = new Scanner(System.in);
	        int matrixone[ ][ ]= new int [2][2];
	        int matrixtwo[ ][ ]= new int [2][2];

	        System.out.println("Enter the matrix one");
	        for(int i=0;i<2;i++)
	        {
	        	for(int j=0;j<2;j++)
	        	{
	        		matrixone[i][j]=sc.nextInt();
	        	}
	        }
	       
	        for(int i=0;i<2;i++)
	        {
	        	for(int j=0;j<2;j++)
	        	{
	        		System.out.print(matrixone[i][j]+" ");
	        	}
	        	System.out.println( );
	}
	        System.out.println("Enter the matrix two");
	        for(int i=0;i<2;i++)
	        {
	        	for(int j=0;j<2;j++)
	        	{
	        		matrixtwo[i][j]=sc.nextInt();
	        	}
	        }
	       
	        for(int i=0;i<2;i++)
	        {
	        	for(int j=0;j<2;j++)
	        	{
	        		System.out.print(matrixtwo[i][j]+" ");
	        	}
	        	System.out.println( );
	}
	       
	
	           for(int i=0;i<2;i++)
	        {
	        	for(int j=0;j<2;j++)
	        	{
	        		   matrixone[i][j] = matrixtwo[i][j];
	        	}
	        	
	}
	           System.out.println("The matrix is same" );
	}
}