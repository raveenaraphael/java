package array;

import java.util.Scanner;

public class matrixmultiplication {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
	        Scanner sc = new Scanner(System.in);
	        int matrixone[ ][ ]= new int [3][3];
	        int matrixtwo[ ][ ]= new int [3][3];
	        int result[ ][ ]= new int [3][3];
	        System.out.println("Enter the matrix one");
	        for(int i=0;i<3;i++)
	        {
	        	for(int j=0;j<3;j++)
	        	{
	        		matrixone[i][j]=sc.nextInt();
	        	}
	        }
	       
	        for(int i=0;i<3;i++)
	        {
	        	for(int j=0;j<3;j++)
	        	{
	        		System.out.print(matrixone[i][j]+" ");
	        	}
	        	System.out.println( );
	}
	        System.out.println("Enter the matrix two");
	        for(int i=0;i<3;i++)
	        {
	        	for(int j=0;j<3;j++)
	        	{
	        		matrixtwo[i][j]=sc.nextInt();
	        	}
	        }
	       
	        for(int i=0;i<3;i++)
	        {
	        	for(int j=0;j<3;j++)
	        	{
	        		System.out.print(matrixtwo[i][j]+" ");
	        	}
	        	System.out.println( );
	}
	       
	        System.out.println("result ");
	    
	           for(int i=0;i<3;i++)
	        {
	        	for(int j=0;j<3;j++)
	        	{
	        		  result[i][j] += matrixone[i][j] * matrixtwo[j][i];
	        	}
	        	System.out.println( );
	}
	        for(int i=0;i<3;i++)
	        {
	        	for(int j=0;j<3;j++)
	        	{
	        		System.out.print(result[i][j]+" ");
	        	}
	        	System.out.println( );
	}
	}
}