package array;

import java.util.Scanner;

public class searcharray {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int arr[]=new int[5];
		int element,i;
		int flag=0;
        System.out.println("Enter the array ");
				Scanner sc =new Scanner (System.in);
				for ( i=0;i<arr.length;i++) 
				{
					arr[i]=sc.nextInt();
				}
				   System.out.println("Enter the search element ");
					element=sc.nextInt();
				for ( i=0;i<arr.length;i++) 
				{

					if (element==arr[i])
					{
						flag=1;
						break;
					}
				}
				
				if(flag==1)
				{
			 	System.out.println("search element="+element);
	
			         }
					else 
					{
						System.out.println("Invalid");
					}
				}
				
				
	
				
				
				}


	

	

