package array;

public class finalize {
	public void Finalize()
	{
 System.out.println("collected");
}
	public static void main(String[] args) {
		
	}

	finalize sa=new finalize(;)
			sa=null;
	System.gc();
	
}
	
}
