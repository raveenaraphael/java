package cubepkg;

import java.util.Scanner;

public class swapping {
	public static void main(String[] args) {
		System.out.println("Enter 1st number");

		Scanner sc=new Scanner(System.in);
		int a =sc.nextInt();
		System.out.println("The 1st number is="+a);
		
		System.out.println("Enter 2st number");
       int b =sc.nextInt();
		System.out.println("The 2nd number is="+b);
		
		///with out 3rd variable
		a=a+b;
		b=a-b;
		a=a-b;
		
		System.out.println("Swapped 1st number"+a);
		System.out.println("Swapped 2nd number"+b);

		
		
	///with 3rd variable
	//int c=a;
	//	a=b;
	//	b=c;
	//	System.out.println("The first number ="+a);
	//	System.out.println("The second number ="+b);
		
	}

}
