package cubepkg;

import java.util.Scanner;

public class clas {
public static void main(String[] args) {
	System.out.println("Enter number ");

	Scanner sc=new Scanner(System.in);
	int a =sc.nextInt();
   System.out.println(a);
   
	int c= a*a*a;
			System.out.println("Cube ="+c);
	
}
}
