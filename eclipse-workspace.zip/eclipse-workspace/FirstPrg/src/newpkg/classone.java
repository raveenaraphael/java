package newpkg;

public class classone {
public static void main(String[] args) {
	
}
	{
		System.out.println("Hello java");
	}

}
