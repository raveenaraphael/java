package newpkg;

public class classtwo {
	public static void main(String[] args) {
		System.out.println("The Next page");
	}

}
