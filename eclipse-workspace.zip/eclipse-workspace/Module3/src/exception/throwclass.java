package exception;

import java.util.Scanner;

public class throwclass {
	public static void main(String[] args) {
		try {
			Scanner sc = new Scanner(System.in);
			System.out.println("Enter age");
			int age = sc.nextInt();
			if (age < 18) {
				throw new Exception("invalid age");

			} else {
				System.out.println("you can vote");
			}

			//// Multiple catch
		} catch (ArithmeticException e) {
			System.out.println("ArithmeticException");
		}

		catch (ArrayIndexOutOfBoundsException e) {
			System.out.println("ArrayIndexOutOfBoundsException");
		}

		catch (Exception e) {
			System.out.println(e);
		}

	}
}
