package exception;

import java.util.Scanner;

public class throwsclass {
	public static void validate(int age) throws ArithmeticException {

		if (age < 18) {
			throw new ArithmeticException("invalid age");
		} else {
			System.out.println("you can vote");
		}
	}

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter age");
		int age = sc.nextInt();
		try {
			throwsclass.validate(age);
		} catch (Exception e) {
			System.out.println(e);
		}
	}

}
