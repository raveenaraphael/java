package exception;

import java.util.Scanner;

class AgeException extends Exception {
	public AgeException(String s) {
		super(s);
	}

}

public class userexception {
	public static void validate(int age) throws AgeException {

		if (age < 18) {
			throw new AgeException("invalid age");
		} else {
			System.out.println("you can vote");
		}
	}

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter age");
		int age = sc.nextInt();
		try {
			userexception.validate(age);
		} catch (Exception e) {
			System.out.println(e);
		}
	}

}
