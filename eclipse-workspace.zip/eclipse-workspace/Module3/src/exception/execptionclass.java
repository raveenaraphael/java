package exception;

public class execptionclass {
	public static void main(String[] args) {
		try {

			int arr[] = new int[3];
			arr[3] = 1000;

		} catch (Exception e) {
			System.out.println(e);
		} finally {
			System.out.println("exception handling");
		}
	}

}
