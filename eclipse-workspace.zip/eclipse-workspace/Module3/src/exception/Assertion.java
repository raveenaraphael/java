package exception;

import java.util.Scanner;

public class Assertion {
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.println("Enter the Age");
		int age = scanner.nextInt();
		assert age >= 18 : "under age";
		System.out.println("age is" + age);
	}

}
