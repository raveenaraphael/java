package paksample;

public class newpkg {

}
