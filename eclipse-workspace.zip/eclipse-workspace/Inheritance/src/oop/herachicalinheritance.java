package oop;

class Animal2 {
	void eat() {
		System.out.println("Eating");
	}

	void walk() {
		System.out.println("Walking");
	}
}

class dog2 extends Animal2 {
	void bark() {
		System.out.println("Barking");
	}
}

class cat extends Animal2 {
	void play() {
		System.out.println("playing");
	}
}

public class herachicalinheritance {
	public static void main(String[] args) {
		dog2 d = new dog2();
		d.bark();
		d.eat();
		d.walk();

		cat c = new cat();
		c.play();
		c.eat();
		c.walk();

	}

}
