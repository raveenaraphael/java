package oop;

public class addressclassaggration {
	String housename;
	String city;
	String state;

	public addressclassaggration(String housename, String city, String state) {
		this.housename = housename;
		this.city = city;
		this.state = state;
	}

}
