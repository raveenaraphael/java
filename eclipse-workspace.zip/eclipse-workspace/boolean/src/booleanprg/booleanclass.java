package booleanprg;

public class booleanclass {
	public static void main(String[] args) {
		int a=111;
		float b=90.00f;
		double c= 276987578587587d;
		boolean d=true;
		
		System.out.println("Values"+a+ " " +b+ " "  +c+ " "  +d );	}

}
