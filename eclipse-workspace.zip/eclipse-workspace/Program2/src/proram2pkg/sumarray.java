package proram2pkg;

import java.util.Scanner;

public class sumarray {
	public static void main(String[] args) {
		int arr[]=new int[5];
		int nrr[]=new int[5];		
		int drr[]=new int[5];	
	   System.out.println("Enter the array1");
		Scanner sc =new Scanner (System.in);
	
		for ( int i=0;i<arr.length;i++) 
		{
			arr[i]=sc.nextInt();
		}
		   System.out.println("Enter the array2");
			for ( int i=0;i<arr.length;i++) 
			{

				nrr[i]=sc.nextInt();
			}
			int sum=0;
		for ( int i=0;i<arr.length;i++) 
		{
			
               drr[i]=arr[i]+nrr[i];

		}
		System.out.println("Sum of Array");
		for(int i:drr) {
	
		 System.out.println(i);
	}
	}
}
