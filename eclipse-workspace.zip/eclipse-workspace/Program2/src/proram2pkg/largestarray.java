package proram2pkg;

import java.util.Scanner;

public class largestarray {
	public static void main(String[] args) {
		int arr[]=new int[5];
	   System.out.println("Enter the array");
		Scanner sc =new Scanner (System.in);
		int largest=0;
		for (int i=0;i<arr.length;i++) 
		{
			arr[i]=sc.nextInt();
		}
		for (int i=0;i<arr.length;i++)
		{
		   if(arr[i]>=largest)
		    {
	       largest=arr[i];
		    }

		}
	     System.out.println("The largest element ="+largest);
 }
}


