package proram2pkg;

import java.util.Scanner;

public class array {

	public static void main(String[] args) {
		int arr[] = new int[5];
		System.out.println("Enter the num");
		Scanner sc = new Scanner(System.in);
		for (int i = 0; i < arr.length; i++) {
			arr[i] = sc.nextInt();
		}
		int sum = 0;
		for (int i = 0; i < arr.length; i++) {
			sum = sum + arr[i];
		}
		System.out.println(sum);

	}
}
