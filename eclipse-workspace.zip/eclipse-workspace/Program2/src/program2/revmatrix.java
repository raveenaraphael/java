package program2;

import java.util.Scanner;

public class revmatrix {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int arr[]=new int[5];
		int drr[]=new int[5];

		int i=0;
		   System.out.println("Enter the array");
			Scanner sc =new Scanner (System.in);
			for ( i=0;i<arr.length;i++) 
			{
				arr[i]=sc.nextInt();
			}
			
			

				 for (i = 0; i < arr.length; i++)
				 {
					 drr[i] = arr[arr.length - 1 - i];
                }
				 
				 
				 
			System.out.println("Reverse of Array");
			for(int a:drr) {
		
			 System.out.println(a);
		}
			
	
	}

}
