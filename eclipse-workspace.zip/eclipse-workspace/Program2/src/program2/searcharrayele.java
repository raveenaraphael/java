package program2;

import java.util.Scanner;

public class searcharrayele {
	
	int arr[]=new int[5];
sout
		Scanner sc =new Scanner (System.in);
		for (int i=0;i<arr.length;i++) 
		{
			arr[i]=sc.nextInt();
		}

}
}
